# Tag Index

You're currently viewing the **Online Version** of the Obsidian Example Vault. This comes with some limitations, first and foremost: Queries do not execute. Due to that, the Query Overviews are unusable, since they are using dataview themselves.

For a better user experience, it's recommended to [[index|open the vault in Obsidian]].

To navigate the online version you can either use the **search bar** at the top or browse through the page tags:

[TAGS]