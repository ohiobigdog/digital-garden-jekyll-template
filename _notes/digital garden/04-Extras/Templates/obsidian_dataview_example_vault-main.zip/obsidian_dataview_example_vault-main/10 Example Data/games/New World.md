---
name: New World
publisher: Amazon Games
developer: Amazon Games
price: 39.99
genre: Action, Adventure, Massively Multiplayer, RPG
languages: English, French, Italian, German, Spanish - Spain, Polish, Portuguese - Brazil, Spanish - Latin America
---
#games #genre/action

# New World

....