---
name: Among Us
publisher: Innersloth
developer: Innersloth
price: 4.99
genre: Casual
languages: English, Portuguese - Brazil, Spanish - Latin America, Spanish - Spain, Korean, Russian, French, Italian, German, Dutch, Japanese, Portuguese, Simplified Chinese, Traditional Chinese
---
#games

# Among Us

....