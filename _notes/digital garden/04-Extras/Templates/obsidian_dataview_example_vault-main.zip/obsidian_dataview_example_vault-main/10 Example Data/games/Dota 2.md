---
name: Dota 2
publisher: Valve
developer: Valve
price: 0
genre: Action, Free to Play, Strategy
languages: English, Bulgarian, Czech, Danish, Dutch, Finnish, French, German, Greek, Hungarian, Italian, Japanese, Korean, Norwegian, Polish, Portuguese, Portuguese - Brazil, Romanian, Russian, Simplified Chinese, Spanish - Spain, Swedish, Thai, Traditional Chinese, Turkish, Ukrainian, Spanish - Latin America, Vietnamese
---
#games #genre/action

# Dota 2

....