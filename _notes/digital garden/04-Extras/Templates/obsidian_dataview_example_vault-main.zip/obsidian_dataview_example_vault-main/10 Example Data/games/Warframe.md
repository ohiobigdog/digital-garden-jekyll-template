---
name: Warframe
publisher: Digital Extremes
developer: Digital Extremes
price: 0
genre: Action, Free to Play, RPG
languages: English, German, French, Italian, Korean, Spanish - Spain, Simplified Chinese, Russian, Japanese, Polish, Portuguese - Brazil, Traditional Chinese, Turkish, Ukrainian
---
#games #genre/action
 
# Warframe

....