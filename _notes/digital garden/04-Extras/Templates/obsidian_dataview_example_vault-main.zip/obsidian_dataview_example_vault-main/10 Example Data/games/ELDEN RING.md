---
name: ELDEN RING
publisher: FromSoftware Inc., Bandai Namco Entertainment
developer: FromSoftware Inc.
price: 59.99
genre: Action, RPG
languages: English, French, Italian, German, Spanish - Spain, Japanese, Korean, Polish, Portuguese - Brazil, Russian, Simplified Chinese, Spanish - Latin America, Thai, Traditional Chinese
---
#games #genre/action

# ELDEN RING

....