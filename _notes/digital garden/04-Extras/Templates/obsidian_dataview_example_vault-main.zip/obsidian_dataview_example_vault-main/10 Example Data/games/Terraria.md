---
name: Terraria
publisher: Re-Logic
developer: Re-Logic
price: 9.99
genre: Action, Adventure, Indie, RPG
languages: English, French, Italian, German, Spanish - Spain, Polish, Portuguese - Brazil, Russian, Simplified Chinese
---
#games #genre/action

# Terraria

....