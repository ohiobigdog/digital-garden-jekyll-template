---
id: LOTR02
lang: DE
---