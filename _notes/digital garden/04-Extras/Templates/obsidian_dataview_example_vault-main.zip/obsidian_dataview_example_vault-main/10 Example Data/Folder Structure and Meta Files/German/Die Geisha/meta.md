---
id: MOG
lang: DE
---