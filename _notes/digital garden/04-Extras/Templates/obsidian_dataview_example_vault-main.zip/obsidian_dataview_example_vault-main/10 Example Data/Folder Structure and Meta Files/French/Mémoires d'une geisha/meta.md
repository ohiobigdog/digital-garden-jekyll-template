---
id: MOG
lang: FR
---