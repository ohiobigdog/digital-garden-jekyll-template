---
author: Dora D
booktopics:
- lost earth
- Cyborgs
genres:
- Science-Fiction
- Dystopia
totalPages: 431
cover-img: "https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1539934542i/40048350.jpg"
---
#type/books

This is an example book excerpt. Whatever.

pagesRead:: 80

