---
author: Conrad C
booktopics:
- cats
genres:
- Children
totalPages: 512
cover-img: "https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1415428227i/20518872.jpg"
---
#type/books

This is an example book excerpt. Blahblah. Whatever.

pagesRead:: 0