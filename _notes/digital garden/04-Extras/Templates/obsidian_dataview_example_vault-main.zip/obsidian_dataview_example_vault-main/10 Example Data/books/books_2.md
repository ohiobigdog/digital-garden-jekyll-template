---
author: Alice A
booktopics:
- middleage
- elves
- runes
genres:
- Fantasy
- Historical
- Magic
totalPages: 99
cover-img: "https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1472119680i/27833670.jpg"
---
#type/books

This is an example book excerpt. Whatever.

pagesRead:: 99

