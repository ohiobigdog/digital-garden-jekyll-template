---
author:
booktopics:
genres:
- 
totalPages: 347
---

This is an example book excerpt. Blahblah. Whatever.

pagesRead:: 0