---
author: Berta B
booktopics:
- coming of age
- magical items
- first love
genres:
- Romance
- Children
- Magic
totalPages: 99

---


This is an example book excerpt. Whatever.

pagesRead:: 15

