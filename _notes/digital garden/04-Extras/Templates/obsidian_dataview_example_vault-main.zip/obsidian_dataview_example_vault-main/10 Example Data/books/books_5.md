---
author: Conrad C
booktopics:
- AR
genres:
- Science-Fiction
totalPages: 307
cover-img: "https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1546512443i/43451211.jpg"
---
#type/books

This is an example book excerpt. Blahblah. Whatever.

pagesRead:: 271