---
author: Berta B
booktopics:
- lost earth
- virtual reality
genres:
- Science-Fiction
- Dystopia
totalPages: 99
Cover-Img: "https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1599649084i/30753841.jpg"
---
#type/books

This is an example book excerpt. Whatever.

pagesRead:: 55

