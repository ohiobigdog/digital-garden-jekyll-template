---
class: architecture
received: 2022-03-09
due: 2022-04-05
---

Needs to have at least 10 pages. 

- [ ] assignment task with due date [duedate:: 2023-03-03]
- [ ] assignment task with due date [duedate:: 2022-11-19]