---
class: spanish
received: 2022-06-28
due: 2022-12-04
---

Needs to have at least 19 pages. 

- [x] Assignment task 1 ✅ 2022-09-02
- [x] Assignment task 2
- [ ] Assignment task 3
- [x] Assignment task 4 ✅ 2022-09-04