---
class: history
received: 2022-03-22
due: 2022-06-27
---

Needs to have at least 26 pages. 

- [x] Assignment task 1 [completion:: 2022-09-06]
- [ ] Assignment task 2
- [x] Assignment task 3 [completion:: 2022-09-06]