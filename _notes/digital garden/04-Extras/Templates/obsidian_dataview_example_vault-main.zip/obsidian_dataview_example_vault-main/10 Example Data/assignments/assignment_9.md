---
class: english
received: 2022-02-08
due: 2022-11-16
---

Needs to have at least 32 pages. 

- [ ] Assignment task 1 #later
- [x] Assignment task 2
- [ ] Assignment task 3
- [x] Assignment task 4 ✅ 2022-08-12
- [x] Assignment task 5 [completion:: 2022-08-23]
- [ ] Assignment task 6 #later
- [ ] Assignment task 7