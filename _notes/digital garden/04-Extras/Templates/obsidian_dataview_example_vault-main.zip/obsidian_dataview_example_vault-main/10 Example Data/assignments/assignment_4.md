---
class: history
received: 2022-02-09
due: 2022-10-10
---

Needs to have at least 9 pages. 

- [ ] Assignment task 1 #later
- [x] Assignment task 2
- [ ] Assignment task 3