---
class: math
received: 2022-04-15
due: 2022-09-28
---

Needs to have at least 10 pages. 

- [x] Assignment task 1 ✅ 2022-09-06
- [ ] Assignment task 2
- [x] Assignment task 3