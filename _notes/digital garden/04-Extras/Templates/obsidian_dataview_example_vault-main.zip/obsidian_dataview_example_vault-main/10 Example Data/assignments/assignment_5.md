---
class: history
received: 2022-03-20
due: 2022-05-05
---

Needs to have at least 31 pages. 

- [ ] assignment task with due date [duedate:: 2023-02-12]
- [ ] assignment task with due date [duedate:: 2022-12-24]