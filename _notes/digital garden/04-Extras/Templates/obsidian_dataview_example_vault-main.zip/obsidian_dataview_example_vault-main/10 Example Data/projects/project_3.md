
# Project project_3

This is some finished project. I had tasks to do here, but I'm done!

**status**:: finished
started:: 2021-03-16
finished:: 2022-02-04
**Project ID**::  922
**tags**:: #clientA
**working hours**:: 03:38, 02:42, 02:24, 05:46, 01:56

- [x] Task 1 of project_3 
- [x] Task 2 of project_3 
- [x] Task 3 of project_3 
- [x] Task 4 of project_3 
- [x] Task 5 of project_3 (with subtasks)
  - [x] Subtask 5.1 of project_3 
  - [x] Subtask 5.2 of project_3 
- [x] Task 6 of project_3 