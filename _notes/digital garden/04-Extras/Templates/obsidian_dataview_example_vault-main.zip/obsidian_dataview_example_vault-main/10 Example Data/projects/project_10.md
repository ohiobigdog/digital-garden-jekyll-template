# Project project_10

This is some finished project. I had tasks to do here, but I'm done!

**status**:: finished
started:: 2022-07-22
finished:: 2022-08-07
**Project ID**::  781
**tags**:: #privateProject
**working hours**:: 01:02, 01:18

- [x] Task 1 of project_10 
- [x] Task 2 of project_10
- [x] Task 3 of project_10

- [ ] medium stuff [priority:: medium]
- [ ] medium stuff [priority::medium]