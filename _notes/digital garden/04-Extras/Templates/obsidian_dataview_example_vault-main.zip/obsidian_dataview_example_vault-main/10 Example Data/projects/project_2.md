# Project project_2

open project. work, work...

**status**:: waiting
started:: 2022-06-06
finished:: 
**Project ID**::  595
**tags**:: #clientA
**working hours**:: 00:16, 02:04

- [ ] Task 1 of project_2 
- [ ] Task 2 of project_2 
- [ ] Task 3 of project_2 (with subtasks)
  - [x] Subtask 5.1 of project_2 
  - [ ] Subtask 5.2 of project_2 
- [ ] Task 4 of project_2 

## Urgent 

- [ ] Urgent task of project_2 1
- [ ] Urgent task of project_2 2