
# Project project_5

This is some finished project. I had tasks to do here, but I'm done!

**status**:: finished
started:: 2021-06-13
finished:: 2022-02-06
**Project ID**::  781
**tags**:: #privateProject
**working hours**:: 03:17, 02:18

- [x] Task 1 of project_5 
- [x] Task 2 of project_5 
- [x] Task 3 of project_5 
- [x] Task 4 of project_5 
- [x] Task 5 of project_5 (with subtasks)
  - [x] Subtask 5.1 of project_5 
  - [x] Subtask 5.2 of project_5 
- [x] Task 6 of project_5 

- [x] done task with [priority:: medium] and other stuff
- [ ] open task with [priority:: medium] and other stuff