# Project project_6

open project. work, work...

**status**:: in-progress
started:: 2022-06-06
finished:: 
**Project ID**:: 555
**tags**:: #clientA
**working hours**:: 03:59, 01:03

- [x] Task 1 of project_6 
- [x] Task 2 of project_6 
- [ ] Task 3 of project_6 (with subtasks)
  - [x] Subtask 5.1 of project_6 
  - [ ] Subtask 5.2 of project_6 
- [ ] Task 4 of project_6 

## Urgent

- [ ] Urgent task of project_6