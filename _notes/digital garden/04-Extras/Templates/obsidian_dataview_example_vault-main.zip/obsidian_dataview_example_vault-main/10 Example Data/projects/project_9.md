# Project project_9

open project. work, work...

**status**:: waiting
started:: 2022-02-22
finished:: 
**Project ID**::  533
**tags**:: #clientB
**working hours**:: 00:52, 02:16, 02:11, 02:32

- [x] Task 1 of project_9 
- [ ] Task 2 of project_9 
- [ ] Task 3 of project_9 (with subtasks)
  - [x] Subtask 5.1 of project_9 
  - [ ] Subtask 5.2 of project_9 
- [x] Task 4 of project_9 