
# Project project_4

This is some finished project. I had tasks to do here, but I'm done!

**status**:: waiting
started:: 2021-11-15
finished:: 2022-07-04
**Project ID**::  836
**tags**:: #clientA
**working hours**:: 04:30, 03:03

- [x] Task 1 of project_4 
- [x] Task 2 of project_4 
- [x] Task 3 of project_4 
- [x] Task 4 of project_4 
- [x] Task 5 of project_4 (with subtasks)
  - [x] Subtask 5.1 of project_4 
  - [x] Subtask 5.2 of project_4 
- [x] Task 6 of project_4 