
# Project project_8

This is some finished project. I had tasks to do here, but I'm done!

**status**:: finished
started:: 2021-10-19
finished:: 2022-07-22
**Project ID**::  984
**tags**:: #clientC
**working hours**:: 00:52, 02:16, 03:37, 06:09, 03:38

- [x] Task 1 of project_8 
- [x] Task 2 of project_8 
- [x] Task 3 of project_8 
- [x] Task 4 of project_8 
- [x] Task 5 of project_8 (with subtasks)
  - [x] Subtask 5.1 of project_8 
  - [x] Subtask 5.2 of project_8 
- [x] Task 6 of project_8 


- [ ] [priority:: low] low prio task
- [ ] [priority:: low] low prio task
- [ ] [priority:: low] low prio task
- [ ] [priority:: low] low prio task
- [ ] [priority:: low] low prio task
- [ ] [priority:: low] low prio task