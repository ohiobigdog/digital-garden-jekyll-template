
# Project project_1

This is some finished project. I had tasks to do here, but I'm done!

**status**:: finished
started:: 2021-04-26
finished:: 2022-07-02
**Project ID**:: 149
**tags**:: #clientB
**working hours**:: 02:02, 01:54

- [x] Task 1 of project_1 
- [x] Task 2 of project_1 
- [x] Task 3 of project_1 
- [x] Task 4 of project_1 
- [x] Task 5 of project_1 (with subtasks)
  - [x] Subtask 5.1 of project_1 
  - [x] Subtask 5.2 of project_1 
- [x] Task 6 of project_1 


- [ ] Task with priority [priority:: low]
- [ ] [priority::high] important task, do ASAP