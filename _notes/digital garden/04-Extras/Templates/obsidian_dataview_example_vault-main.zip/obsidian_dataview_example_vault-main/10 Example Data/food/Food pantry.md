# Food pantry

## Carbohydrates
- 500g oatmeal [best-before:: 2023-08-12]
- 500g whole grain pasta [best-before:: 2025-04-27]
- 1000g  rice [best-before:: 2024-06-07]
- 1 pack crispbread [best-before:: 2023-03-30]

## Meat & Ready-made
- 1 jar of sausages [best-before:: 2024-04-20]
- 3 cans of stew [best-before:: 2025-04-30]
- 2 pizzas [best-before:: 2023-03-20]

## Vegetables
- 1 can of peas [best-before:: 2025-06-30]
- 2 jars of mushrooms [best-before:: 2025-10-01]
- 1 jar of pickled cucumbers [best-before:: 2024-07-11]
- 2 can of corn [best-before:: 2024-08-02]
- 1 can tomatoes [best-before:: 2024-12-30]
- 1 jar chickpeas [best-before:: 2025-01-01]

## Fruit
- 2 cans of mandarin [best-before:: 2024-11-17]
- 1 can fruit cocktail [best-before:: 2023-09-28]

## Other
- 1 can of coconut milk [best-before:: 2024-06-12]
- 1 bar of milk chocolate [best-before:: 2023-03-21]