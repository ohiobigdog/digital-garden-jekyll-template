---
recipe-type: vegetarian
source: https://www.recipetineats.com/mushroom-pasta/
time: 20 min
ingredients: 
- spaghetti
- mushrooms
- olive oil
- garlic
- salt and pepper
- grated parmesan cheese 
- parsley
---

# Mushroom Pasta

## Ingredients

-  [ ] 200g / 7 oz short pasta like orecchiette, penne, macaroni (Note 1)
- [ ] 160g/6 oz long pasta - spaghetti, fettucine (Note 1)
- [ ] 400g / 14 oz mushrooms , sliced 1/2 cm / 1/5" thick (Note 2)
- [ ] 50g / 3 tbsp unsalted butter , separated
- [ ] 1 tbsp olive oil
- [ ] 2 garlic cloves , finely minced
- [ ] 1/2 tsp each salt and pepper
- [ ] 1/2 cup freshly grated parmesan cheese (or 1/4 cup store bought grated)- [ ] 
- [ ] Parsley , finely chopped
- [ ] Parmesan cheese , grated