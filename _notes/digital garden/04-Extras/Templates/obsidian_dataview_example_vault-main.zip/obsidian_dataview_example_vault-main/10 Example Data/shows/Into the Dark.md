---
Title: Into the Dark
Genre: ['Drama', 'Horror', 'Thriller']
Network: Hulu

Seasons: 2
Episodes: 24
Runtime: 85
Show_status: Ended

Status: 'Stopped watching'
Rating: 
Would rewatch: false
---

## Season 2
- [ ] Ep 12 - Blood Moon [Release date:: 2021-03-26]
- [ ] Ep 11 - Tentacles [Release date:: 2021-02-12]
- [ ] Ep 10 - The Current Occupant [Release date:: 2020-07-17]
- [ ] Ep 9 - Good Boy [Release date:: 2020-06-12]
- [ ] Ep 8 - Delivered [Release date:: 2020-05-08]
- [ ] Ep 7 - Pooka Lives! [Release date:: 2020-04-03]
- [ ] Ep 6 - Crawlers [Release date:: 2020-03-06]
- [ ] Ep 5 - My Valentine [Release date:: 2020-02-07]
- [ ] Ep 4 - Midnight Kiss [Release date:: 2019-12-27]
- [ ] Ep 3 - A Nasty Piece of Work [Release date:: 2019-12-06]
- [ ] Ep 2 - Pilgrim [Release date:: 2019-11-01]
- [ ] Ep 1 - Uncanny Annie [Release date:: 2019-10-04]

## Season 1
- [ ] Ep 12 - Pure [Release date:: 2019-09-06]
- [ ] Ep 11 - School Spirit [Release date:: 2019-08-02]
- [ ] Ep 10 - Culture Shock [Release date:: 2019-07-04]
- [ ] Ep 9 - They Come Knocking [Release date:: 2019-06-07]
- [ ] Ep 8 - All That We Destroy [Release date:: 2019-05-03]
- [ ] Ep 7 - I'm Just F*cking with You [Release date:: 2019-04-01]
- [ ] Ep 6 - Treehouse [Release date:: 2019-03-01]
- [ ] Ep 5 - Down [Release date:: 2019-02-01]
- [ ] Ep 4 - New Year, New You [Release date:: 2018-12-28]
- [ ] Ep 3 - Pooka! [Release date:: 2018-12-07]
- [x] Ep 2 - Flesh & Blood [Release date:: 2018-11-02]
- [x] Ep 1 - The Body [Release date:: 2018-10-05]


