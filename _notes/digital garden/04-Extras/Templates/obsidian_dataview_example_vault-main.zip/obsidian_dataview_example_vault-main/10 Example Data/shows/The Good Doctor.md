---
Title: The Good Doctor
Genre: ['Drama', 'Medical']
Network: ABC

Seasons: 6
Episodes: 95
Runtime: 60
Show_status: Running

Status: 'Stopped watching'
Rating: 3/5
Would rewatch: 
---

## Season 6
- [ ] Ep 1 - TBA [Release date:: 2022-10-03]

## Season 5
- [ ] Ep 18 - Sons [Release date:: 2022-05-16]
- [ ] Ep 17 - The Lea Show [Release date:: 2022-05-09]
- [ ] Ep 16 - The Shaun Show [Release date:: 2022-05-02]
- [ ] Ep 15 - My Way [Release date:: 2022-04-18]
- [ ] Ep 14 - Potluck [Release date:: 2022-04-11]
- [ ] Ep 13 - Growing Pains [Release date:: 2022-04-04]
- [ ] Ep 12 - Dry Spell [Release date:: 2022-03-28]
- [ ] Ep 11 - The Family [Release date:: 2022-03-21]
- [ ] Ep 10 - Cheat Day [Release date:: 2022-03-14]
- [ ] Ep 9 - Yippee Ki-Yay [Release date:: 2022-03-07]
- [ ] Ep 8 - Rebellion [Release date:: 2022-02-28]
- [ ] Ep 7 - Expired [Release date:: 2021-11-22]
- [ ] Ep 6 - One Heart [Release date:: 2021-11-15]
- [ ] Ep 5 - Crazytown [Release date:: 2021-11-01]
- [ ] Ep 4 - Rationality [Release date:: 2021-10-25]
- [ ] Ep 3 - Measure of Intelligence [Release date:: 2021-10-11]
- [ ] Ep 2 - Piece of Cake [Release date:: 2021-10-04]
- [ ] Ep 1 - New Beginnings [Release date:: 2021-09-27]

## Season 4
- [ ] Ep 20 - Vamos [Release date:: 2021-06-07]
- [ ] Ep 19 - Venga [Release date:: 2021-05-31]
- [ ] Ep 18 - Forgive or Forget [Release date:: 2021-05-24]
- [ ] Ep 17 - Letting Go [Release date:: 2021-05-17]
- [ ] Ep 16 - Dr. Ted [Release date:: 2021-05-10]
- [ ] Ep 15 - Waiting [Release date:: 2021-04-26]
- [ ] Ep 14 - Gender Reveal [Release date:: 2021-04-19]
- [ ] Ep 13 - Spilled Milk [Release date:: 2021-03-29]
- [ ] Ep 12 - Teeny Blue Eyes [Release date:: 2021-03-22]
- [ ] Ep 11 - We're All Crazy Sometimes [Release date:: 2021-03-08]
- [ ] Ep 10 - Decrypt [Release date:: 2021-02-22]
- [ ] Ep 9 - Irresponsible Salad Bar Practices [Release date:: 2021-02-15]
- [ ] Ep 8 - Parenting [Release date:: 2021-01-25]
- [ ] Ep 7 - The Uncertainty Principle [Release date:: 2021-01-18]
- [ ] Ep 6 - Lim [Release date:: 2021-01-11]
- [ ] Ep 5 - Fault [Release date:: 2020-11-30]
- [ ] Ep 4 - Not the Same [Release date:: 2020-11-23]
- [ ] Ep 3 - Newbies [Release date:: 2020-11-16]
- [ ] Ep 2 - Frontline, Part 2 [Release date:: 2020-11-09]
- [ ] Ep 1 - Frontline, Part 1 [Release date:: 2020-11-02]

## Season 3
- [ ] Ep 20 - I Love You [Release date:: 2020-03-30]
- [ ] Ep 19 - Hurt [Release date:: 2020-03-23]
- [ ] Ep 18 - Heartbreak [Release date:: 2020-03-09]
- [ ] Ep 17 - Fixation [Release date:: 2020-03-02]
- [ ] Ep 16 - Autopsy [Release date:: 2020-02-24]
- [ ] Ep 15 - Unsaid [Release date:: 2020-02-17]
- [ ] Ep 14 - Influence [Release date:: 2020-02-10]
- [ ] Ep 13 - Sex and Death [Release date:: 2020-01-27]
- [ ] Ep 12 - Mutations [Release date:: 2020-01-20]
- [ ] Ep 11 - Fractured [Release date:: 2020-01-13]
- [ ] Ep 10 - Friends and Family [Release date:: 2019-12-02]
- [ ] Ep 9 - Incomplete [Release date:: 2019-11-25]
- [ ] Ep 8 - Moonshot [Release date:: 2019-11-18]
- [ ] Ep 7 - SFAD [Release date:: 2019-11-11]
- [ ] Ep 6 - 45-Degree Angle [Release date:: 2019-11-04]
- [ ] Ep 5 - First Case, Second Base [Release date:: 2019-10-21]
- [ ] Ep 4 - Take My Hand [Release date:: 2019-10-14]
- [ ] Ep 3 - Claire [Release date:: 2019-10-07]
- [ ] Ep 2 - Debts [Release date:: 2019-09-30]
- [ ] Ep 1 - Disaster [Release date:: 2019-09-23]

## Season 2
- [ ] Ep 18 - Trampoline [Release date:: 2019-03-11]
- [ ] Ep 17 - Breakdown [Release date:: 2019-03-04]
- [ ] Ep 16 - Believe [Release date:: 2019-02-25]
- [ ] Ep 15 - Risk and Reward [Release date:: 2019-02-18]
- [ ] Ep 14 - Faces [Release date:: 2019-02-04]
- [ ] Ep 13 - Xin [Release date:: 2019-01-28]
- [ ] Ep 12 - Aftermath [Release date:: 2019-01-21]
- [ ] Ep 11 - Quarantine, Part 2 [Release date:: 2019-01-14]
- [ ] Ep 10 - Quarantine, Part 1 [Release date:: 2018-12-03]
- [ ] Ep 9 - Empathy [Release date:: 2018-11-26]
- [ ] Ep 8 - Stories [Release date:: 2018-11-19]
- [ ] Ep 7 - Hubert [Release date:: 2018-11-12]
- [ ] Ep 6 - Two-Ply (or Not Two-Ply) [Release date:: 2018-11-05]
- [ ] Ep 5 - Carrots [Release date:: 2018-10-29]
- [ ] Ep 4 - Tough Titmouse [Release date:: 2018-10-15]
- [ ] Ep 3 - 36 Hours [Release date:: 2018-10-08]
- [ ] Ep 2 - Middle Ground [Release date:: 2018-10-01]
- [ ] Ep 1 - Hello [Release date:: 2018-09-24]

## Season 1
- [ ] Ep 18 - More [Release date:: 2018-03-26]
- [ ] Ep 17 - Smile [Release date:: 2018-03-19]
- [ ] Ep 16 - Pain [Release date:: 2018-03-12]
- [ ] Ep 15 - Heartfelt [Release date:: 2018-02-26]
- [ ] Ep 14 - She [Release date:: 2018-02-05]
- [ ] Ep 13 - Seven Reasons [Release date:: 2018-01-22]
- [ ] Ep 12 - Islands, Part 2 [Release date:: 2018-01-15]
- [ ] Ep 11 - Islands, Part 1 [Release date:: 2018-01-08]
- [x] Ep 10 - Sacrifice [Release date:: 2017-12-04]
- [x] Ep 9 - Intangibles [Release date:: 2017-11-27]
- [x] Ep 8 - Apple [Release date:: 2017-11-20]
- [x] Ep 7 - 22 Steps [Release date:: 2017-11-13]
- [x] Ep 6 - Not Fake [Release date:: 2017-10-30]
- [x] Ep 5 - Point Three Percent [Release date:: 2017-10-23]
- [x] Ep 4 - Pipes [Release date:: 2017-10-16]
- [x] Ep 3 - Oliver [Release date:: 2017-10-09]
- [x] Ep 2 - Mount Rushmore [Release date:: 2017-10-02]
- [x] Ep 1 - Burnt Food [Release date:: 2017-09-25]


