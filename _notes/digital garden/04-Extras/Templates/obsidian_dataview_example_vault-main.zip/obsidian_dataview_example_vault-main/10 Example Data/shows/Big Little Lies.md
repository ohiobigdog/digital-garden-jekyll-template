---
Title: Big Little Lies
Genre: ['Drama', 'Comedy', 'Mystery']
Network: HBO

Seasons: 2
Episodes: 14
Runtime: 60
Show_status: Ended

Status: 'Stopped watching'
Rating: 3/5
Would rewatch: 
---

## Season 2
- [ ] Ep 7 - I Want to Know [Release date:: 2019-07-21]
- [ ] Ep 6 - The Bad Mother [Release date:: 2019-07-14]
- [ ] Ep 5 - Kill Me [Release date:: 2019-07-07]
- [ ] Ep 4 - She Knows [Release date:: 2019-06-30]
- [ ] Ep 3 - The End of the World [Release date:: 2019-06-23]
- [ ] Ep 2 - Tell-Tale Hearts [Release date:: 2019-06-16]
- [ ] Ep 1 - What Have They Done? [Release date:: 2019-06-09]

## Season 1
- [x] Ep 7 - You Get What You Need [Release date:: 2017-04-02]
- [x] Ep 6 - Burning Love [Release date:: 2017-03-26]
- [x] Ep 5 - Once Bitten [Release date:: 2017-03-19]
- [x] Ep 4 - Push Comes to Shove [Release date:: 2017-03-12]
- [x] Ep 3 - Living the Dream [Release date:: 2017-03-05]
- [x] Ep 2 - Serious Mothering [Release date:: 2017-02-26]
- [x] Ep 1 - Somebody's Dead [Release date:: 2017-02-19]


