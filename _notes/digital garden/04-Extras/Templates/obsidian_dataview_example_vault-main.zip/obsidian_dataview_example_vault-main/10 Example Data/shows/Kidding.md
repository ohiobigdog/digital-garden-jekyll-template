---
Title: Kidding
Genre: ['Drama', 'Comedy']
Network: Showtime

Seasons: 2
Episodes: 20
Runtime: 30
Show_status: Ended

Status: 'Stopped watching'
Rating: 3/5
Would rewatch: false
---

## Season 2
- [ ] Ep 10 - The Puppet Dalai Lama [Release date:: 2020-03-08]
- [ ] Ep 9 - The Nightingale Pledge [Release date:: 2020-03-08]
- [ ] Ep 8 - A Seat on the Rocket [Release date:: 2020-03-01]
- [ ] Ep 7 - The Acceptance Speech [Release date:: 2020-03-01]
- [ ] Ep 6 - The Death of Fil [Release date:: 2020-02-23]
- [ ] Ep 5 - Episode 3101 [Release date:: 2020-02-23]
- [ ] Ep 4 - I Wonder What Grass Tastes Like [Release date:: 2020-02-16]
- [ ] Ep 3 - I'm Listening [Release date:: 2020-02-16]
- [ ] Ep 2 - Up, Down and Everything in Between [Release date:: 2020-02-09]
- [ ] Ep 1 - The Cleanest Liver in Columbus, Ohio [Release date:: 2020-02-09]

## Season 1
- [ ] Ep 10 - Some Day [Release date:: 2018-11-11]
- [ ] Ep 9 - Lt. Pickles [Release date:: 2018-11-04]
- [ ] Ep 8 - Philliam [Release date:: 2018-10-28]
- [ ] Ep 7 - Kintsugi [Release date:: 2018-10-21]
- [ ] Ep 6 - The Cookie [Release date:: 2018-10-14]
- [ ] Ep 5 - The New You [Release date:: 2018-10-07]
- [x] Ep 4 - Bye, Mom! [Release date:: 2018-09-30]
- [x] Ep 3 - Every Pain Needs a Name [Release date:: 2018-09-23]
- [x] Ep 2 - Pusillanimous [Release date:: 2018-09-16]
- [x] Ep 1 - Green Means Go [Release date:: 2018-09-09]


