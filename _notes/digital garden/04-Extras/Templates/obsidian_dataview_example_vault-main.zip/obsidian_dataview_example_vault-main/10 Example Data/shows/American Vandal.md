---
Title: American Vandal
Genre: ['Comedy', 'Crime']
Network: Netflix

Seasons: 2
Episodes: 16
Runtime: 34
Show_status: Ended

Status: 'Watched all'
Rating: 4/5
Would rewatch: 
---

## Season 2
- [x] Ep 8 - The Dump [Release date:: 2018-09-14]
- [x] Ep 7 - Sh*t Storm [Release date:: 2018-09-14]
- [x] Ep 6 - All Backed Up [Release date:: 2018-09-14]
- [x] Ep 5 - Wiped Clean [Release date:: 2018-09-14]
- [x] Ep 4 - Sh*t Talk [Release date:: 2018-09-14]
- [x] Ep 3 - Leaving a Mark [Release date:: 2018-09-14]
- [x] Ep 2 - #2 [Release date:: 2018-09-14]
- [x] Ep 1 - The Brownout [Release date:: 2018-09-14]

## Season 1
- [x] Ep 8 - Clean Up [Release date:: 2017-09-15]
- [x] Ep 7 - Climax [Release date:: 2017-09-15]
- [x] Ep 6 - Gag Order [Release date:: 2017-09-15]
- [x] Ep 5 - Premature Theories [Release date:: 2017-09-15]
- [x] Ep 4 - Growing Suspicion [Release date:: 2017-09-15]
- [x] Ep 3 - Nailed [Release date:: 2017-09-15]
- [x] Ep 2 - A Limp Alibi [Release date:: 2017-09-15]
- [x] Ep 1 - Hard Facts: Vandalism and Vulgarity [Release date:: 2017-09-15]


