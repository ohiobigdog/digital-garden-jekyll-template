---
Title: American Gods
Genre: ['Drama', 'Action', 'Fantasy']
Network: STARZ

Seasons: 3
Episodes: 26
Runtime: 60
Show_status: Ended

Status: 'Going to watch'
Rating: 3/5
Would rewatch: true
---

## Season 3
- [ ] Ep 10 - Tears of the Wrath-Bearing Tree [Release date:: 2021-03-21]
- [ ] Ep 9 - The Lake Effect [Release date:: 2021-03-14]
- [ ] Ep 8 - The Rapture of Burning [Release date:: 2021-03-07]
- [ ] Ep 7 - Fire and Ice [Release date:: 2021-02-28]
- [ ] Ep 6 - Conscience of the King [Release date:: 2021-02-21]
- [ ] Ep 5 - Sister Rising [Release date:: 2021-02-14]
- [ ] Ep 4 - The Unseen [Release date:: 2021-01-31]
- [ ] Ep 3 - Ashes and Demons [Release date:: 2021-01-24]
- [ ] Ep 2 - Serious Moonlight [Release date:: 2021-01-17]
- [ ] Ep 1 - A Winter's Tale [Release date:: 2021-01-10]

## Season 2
- [ ] Ep 8 - Moon Shadow [Release date:: 2019-04-28]
- [ ] Ep 7 - Treasure of the Sun [Release date:: 2019-04-21]
- [ ] Ep 6 - Donar the Great [Release date:: 2019-04-14]
- [ ] Ep 5 - The Ways of the Dead [Release date:: 2019-04-07]
- [ ] Ep 4 - The Greatest Story Ever Told [Release date:: 2019-03-31]
- [ ] Ep 3 - Muninn [Release date:: 2019-03-24]
- [ ] Ep 2 - The Beguiling Man [Release date:: 2019-03-17]
- [ ] Ep 1 - House on the Rock [Release date:: 2019-03-10]

## Season 1
- [x] Ep 8 - Come to Jesus [Release date:: 2017-06-18]
- [x] Ep 7 - A Prayer for Mad Sweeney [Release date:: 2017-06-11]
- [x] Ep 6 - A Murder of Gods [Release date:: 2017-06-04]
- [x] Ep 5 - Lemon Scented You [Release date:: 2017-05-28]
- [x] Ep 4 - Git Gone [Release date:: 2017-05-21]
- [x] Ep 3 - Head Full of Snow [Release date:: 2017-05-14]
- [x] Ep 2 - The Secret of Spoons [Release date:: 2017-05-07]
- [x] Ep 1 - The Bone Orchard [Release date:: 2017-04-30]


