---
Title: Mr. Corman
Genre: ['Drama', 'Comedy']
Network: Apple TV+

Seasons: 1
Episodes: 10
Runtime: 28
Show_status: Ended

Status: 'Stopped watching'
Rating: 
Would rewatch: 
---

## Season 1
- [ ] Ep 10 - The Big Picture [Release date:: 2021-10-01]
- [ ] Ep 9 - Mr. Corman [Release date:: 2021-09-24]
- [ ] Ep 8 - Hope You Feel Better [Release date:: 2021-09-17]
- [ ] Ep 7 - Many Worlds [Release date:: 2021-09-10]
- [ ] Ep 6 - Funeral [Release date:: 2021-09-03]
- [ ] Ep 5 - Action Adventure [Release date:: 2021-08-27]
- [ ] Ep 4 - Mr. Morales [Release date:: 2021-08-20]
- [ ] Ep 3 - Happy Birthday [Release date:: 2021-08-13]
- [x] Ep 2 - Don't Panic [Release date:: 2021-08-06]
- [x] Ep 1 - Good Luck [Release date:: 2021-08-06]


