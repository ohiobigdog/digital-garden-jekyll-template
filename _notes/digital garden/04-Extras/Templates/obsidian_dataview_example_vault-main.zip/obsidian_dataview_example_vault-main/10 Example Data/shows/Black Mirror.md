---
Title: Black Mirror
Genre: ['Drama', 'Science-Fiction', 'Thriller']
Network: Netflix

Seasons: 5
Episodes: 21
Runtime: 63
Show_status: Running

Status: 'Watched all'
Rating: 3/5
Would rewatch: 
---

## Season 5
- [x] Ep 3 - Rachel, Jack and Ashley, Too [Release date:: 2019-06-05]
- [x] Ep 2 - Smithereens [Release date:: 2019-06-05]
- [x] Ep 1 - Striking Vipers [Release date:: 2019-06-05]

## Season 4
- [x] Ep 6 - Black Museum [Release date:: 2017-12-29]
- [x] Ep 5 - Metalhead [Release date:: 2017-12-29]
- [x] Ep 4 - Hang the DJ [Release date:: 2017-12-29]
- [x] Ep 3 - Crocodile [Release date:: 2017-12-29]
- [x] Ep 2 - Arkangel [Release date:: 2017-12-29]
- [x] Ep 1 - USS Callister [Release date:: 2017-12-29]

## Season 3
- [x] Ep 6 - Hated in the Nation [Release date:: 2016-10-21]
- [x] Ep 5 - Men Against Fire [Release date:: 2016-10-21]
- [x] Ep 4 - San Junipero [Release date:: 2016-10-21]
- [x] Ep 3 - Shut Up and Dance [Release date:: 2016-10-21]
- [x] Ep 2 - Playtest [Release date:: 2016-10-21]
- [x] Ep 1 - Nosedive [Release date:: 2016-10-21]

## Season 2
- [x] Ep 3 - The Waldo Moment [Release date:: 2013-02-25]
- [x] Ep 2 - White Bear [Release date:: 2013-02-18]
- [x] Ep 1 - Be Right Back [Release date:: 2013-02-11]

## Season 1
- [x] Ep 3 - The Entire History of You [Release date:: 2011-12-18]
- [x] Ep 2 - Fifteen Million Merits [Release date:: 2011-12-11]
- [x] Ep 1 - The National Anthem [Release date:: 2011-12-04]


