---
Title: The Mandalorian
Genre: ['Action', 'Adventure', 'Science-Fiction']
Network: Disney+

Seasons: 3
Episodes: 16
Runtime: 40
Show_status: Running

Status: 'Watching'
Rating: 
Would rewatch: 
---

## Season 3

## Season 2
- [ ] Ep 8 - Chapter 16: The Rescue [Release date:: 2020-12-18]
- [ ] Ep 7 - Chapter 15: The Believer [Release date:: 2020-12-11]
- [ ] Ep 6 - Chapter 14: The Tragedy [Release date:: 2020-12-04]
- [ ] Ep 5 - Chapter 13: The Jedi [Release date:: 2020-11-27]
- [ ] Ep 4 - Chapter 12: The Siege [Release date:: 2020-11-20]
- [ ] Ep 3 - Chapter 11: The Heiress [Release date:: 2020-11-13]
- [ ] Ep 2 - Chapter 10: The Passenger [Release date:: 2020-11-06]
- [ ] Ep 1 - Chapter 9: The Marshal [Release date:: 2020-10-30]

## Season 1
- [ ] Ep 8 - Chapter 8: Redemption [Release date:: 2019-12-27]
- [ ] Ep 7 - Chapter 7: The Reckoning [Release date:: 2019-12-18]
- [ ] Ep 6 - Chapter 6: The Prisoner [Release date:: 2019-12-13]
- [ ] Ep 5 - Chapter 5: The Gunslinger [Release date:: 2019-12-06]
- [ ] Ep 4 - Chapter 4: Sanctuary [Release date:: 2019-11-29]
- [ ] Ep 3 - Chapter 3: The Sin [Release date:: 2019-11-22]
- [x] Ep 2 - Chapter 2: The Child [Release date:: 2019-11-15]
- [x] Ep 1 - Chapter 1: The Mandalorian [Release date:: 2019-11-12]


