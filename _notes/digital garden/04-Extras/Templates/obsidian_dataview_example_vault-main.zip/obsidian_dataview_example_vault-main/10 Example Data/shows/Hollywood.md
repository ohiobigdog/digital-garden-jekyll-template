---
Title: Hollywood
Genre: ['Drama']
Network: Netflix

Seasons: 1
Episodes: 7
Runtime: 50
Show_status: Ended

Status: 'Going to watch'
Rating: 
Would rewatch: 
---

## Season 1
- [ ] Ep 7 - A Hollywood Ending [Release date:: 2020-05-01]
- [ ] Ep 6 - Meg [Release date:: 2020-05-01]
- [ ] Ep 5 - Jump [Release date:: 2020-05-01]
- [ ] Ep 4 - (Screen) Tests [Release date:: 2020-05-01]
- [ ] Ep 3 - Outlaws [Release date:: 2020-05-01]
- [ ] Ep 2 - Hooray for Hollywood: Part 2 [Release date:: 2020-05-01]
- [ ] Ep 1 - Hooray for Hollywood [Release date:: 2020-05-01]


