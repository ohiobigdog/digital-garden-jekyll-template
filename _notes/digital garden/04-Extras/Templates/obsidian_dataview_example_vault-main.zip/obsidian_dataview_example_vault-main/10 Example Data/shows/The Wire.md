---
Title: The Wire
Genre: ['Drama', 'Crime']
Network: HBO

Seasons: 5
Episodes: 60
Runtime: 60
Show_status: Ended

Status: 'Going to watch'
Rating: 4/5
Would rewatch: true
---

## Season 5
- [ ] Ep 10 - -30- [Release date:: 2008-03-09]
- [ ] Ep 9 - Late Editions [Release date:: 2008-03-02]
- [ ] Ep 8 - Clarifications [Release date:: 2008-02-24]
- [ ] Ep 7 - Took [Release date:: 2008-02-17]
- [ ] Ep 6 - The Dickensian Aspect [Release date:: 2008-02-10]
- [ ] Ep 5 - React Quotes [Release date:: 2008-02-03]
- [ ] Ep 4 - Transitions [Release date:: 2008-01-27]
- [ ] Ep 3 - Not for Attribution [Release date:: 2008-01-20]
- [ ] Ep 2 - Unconfirmed Reports [Release date:: 2008-01-13]
- [ ] Ep 1 - More with Less [Release date:: 2008-01-06]

## Season 4
- [ ] Ep 13 - Final Grades [Release date:: 2006-12-10]
- [ ] Ep 12 - That's Got His Own [Release date:: 2006-12-03]
- [ ] Ep 11 - A New Day [Release date:: 2006-11-26]
- [ ] Ep 10 - Misgivings [Release date:: 2006-11-19]
- [ ] Ep 9 - Know Your Place [Release date:: 2006-11-12]
- [ ] Ep 8 - Corner Boys [Release date:: 2006-11-05]
- [ ] Ep 7 - Unto Others [Release date:: 2006-10-29]
- [ ] Ep 6 - Margin of Error [Release date:: 2006-10-15]
- [ ] Ep 5 - Alliances [Release date:: 2006-10-08]
- [ ] Ep 4 - Refugees [Release date:: 2006-10-01]
- [ ] Ep 3 - Home Room [Release date:: 2006-09-24]
- [ ] Ep 2 - Soft Eyes [Release date:: 2006-09-17]
- [ ] Ep 1 - Boys of Summer [Release date:: 2006-09-10]

## Season 3
- [ ] Ep 12 - Mission Accomplished [Release date:: 2004-12-19]
- [ ] Ep 11 - Middle Ground [Release date:: 2004-12-12]
- [ ] Ep 10 - Reformation [Release date:: 2004-11-28]
- [ ] Ep 9 - Slapstick [Release date:: 2004-11-21]
- [ ] Ep 8 - Moral Midgetry [Release date:: 2004-11-14]
- [ ] Ep 7 - Back Burners [Release date:: 2004-11-07]
- [ ] Ep 6 - Homecoming [Release date:: 2004-10-31]
- [ ] Ep 5 - Straight and True [Release date:: 2004-10-17]
- [ ] Ep 4 - Hamsterdam [Release date:: 2004-10-10]
- [ ] Ep 3 - Dead Soldiers [Release date:: 2004-10-03]
- [ ] Ep 2 - All Due Respect [Release date:: 2004-09-26]
- [ ] Ep 1 - Time After Time [Release date:: 2004-09-19]

## Season 2
- [x] Ep 12 - Port in a Storm [Release date:: 2003-08-24]
- [x] Ep 11 - Bad Dreams [Release date:: 2003-08-17]
- [x] Ep 10 - Storm Warnings [Release date:: 2003-08-10]
- [x] Ep 9 - Stray Rounds [Release date:: 2003-08-03]
- [x] Ep 8 - Duck and Cover [Release date:: 2003-07-27]
- [x] Ep 7 - Backwash [Release date:: 2003-07-13]
- [x] Ep 6 - All Prologue [Release date:: 2003-07-06]
- [x] Ep 5 - Undertow [Release date:: 2003-06-29]
- [x] Ep 4 - Hard Cases [Release date:: 2003-06-22]
- [x] Ep 3 - Hot Shots [Release date:: 2003-06-15]
- [x] Ep 2 - Collateral Damage [Release date:: 2003-06-08]
- [x] Ep 1 - Ebb Tide [Release date:: 2003-06-01]

## Season 1
- [x] Ep 13 - Sentencing [Release date:: 2002-09-08]
- [x] Ep 12 - Cleaning Up [Release date:: 2002-09-01]
- [x] Ep 11 - The Hunt [Release date:: 2002-08-18]
- [x] Ep 10 - The Cost [Release date:: 2002-08-11]
- [x] Ep 9 - Game Day [Release date:: 2002-08-04]
- [x] Ep 8 - Lessons [Release date:: 2002-07-28]
- [x] Ep 7 - One Arrest [Release date:: 2002-07-21]
- [x] Ep 6 - The Wire [Release date:: 2002-07-07]
- [x] Ep 5 - The Pager [Release date:: 2002-06-30]
- [x] Ep 4 - Old Cases [Release date:: 2002-06-23]
- [x] Ep 3 - The Buys [Release date:: 2002-06-16]
- [x] Ep 2 - The Detail [Release date:: 2002-06-09]
- [x] Ep 1 - The Target [Release date:: 2002-06-02]


