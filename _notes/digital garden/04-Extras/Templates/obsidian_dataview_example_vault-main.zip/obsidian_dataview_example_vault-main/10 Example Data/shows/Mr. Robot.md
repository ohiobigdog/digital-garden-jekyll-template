---
Title: Mr. Robot
Genre: ['Drama', 'Crime', 'Thriller']
Network: USA Network

Seasons: 4
Episodes: 45
Runtime: 61
Show_status: Ended

Status: 'Going to watch'
Rating: 4/5
Would rewatch: true
---

## Season 4
- [ ] Ep 13 - Hello, Elliot [Release date:: 2019-12-22]
- [ ] Ep 12 - whoami [Release date:: 2019-12-22]
- [ ] Ep 11 - eXit [Release date:: 2019-12-15]
- [ ] Ep 10 - 410 Gone [Release date:: 2019-12-08]
- [ ] Ep 9 - 409 Conflict [Release date:: 2019-12-01]
- [ ] Ep 8 - 408 Request Timeout [Release date:: 2019-11-24]
- [ ] Ep 7 - 407 Proxy Authentication Required [Release date:: 2019-11-17]
- [ ] Ep 6 - 406 Not Acceptable [Release date:: 2019-11-10]
- [ ] Ep 5 - 405 Method Not Allowed [Release date:: 2019-11-03]
- [ ] Ep 4 - 404 Not Found [Release date:: 2019-10-27]
- [ ] Ep 3 - 403 Forbidden [Release date:: 2019-10-20]
- [ ] Ep 2 - 402 Payment Required [Release date:: 2019-10-13]
- [ ] Ep 1 - 401 Unauthorized [Release date:: 2019-10-06]

## Season 3
- [x] Ep 10 - shutdown -r [Release date:: 2017-12-13]
- [x] Ep 9 - eps3.8_stage3.torrent [Release date:: 2017-12-06]
- [x] Ep 8 - eps3.7_dont-delete-me.ko [Release date:: 2017-11-29]
- [x] Ep 7 - eps3.6_fredrick+tanya.chk [Release date:: 2017-11-22]
- [x] Ep 6 - eps3.5_kill-pr0cess.inc [Release date:: 2017-11-15]
- [x] Ep 5 - eps3.4_runtime-err0r.r00 [Release date:: 2017-11-08]
- [x] Ep 4 - eps3.3_metadata.par2 [Release date:: 2017-11-01]
- [x] Ep 3 - eps3.2_legacy.so [Release date:: 2017-10-25]
- [x] Ep 2 - eps3.1_undo.gz [Release date:: 2017-10-18]
- [x] Ep 1 - eps3.0_power-saver-mode.h [Release date:: 2017-10-11]

## Season 2
- [x] Ep 12 - eps2.9_pyth0n-pt2.p7z [Release date:: 2016-09-21]
- [x] Ep 11 - eps2.9_pyth0n-pt1.p7z [Release date:: 2016-09-14]
- [x] Ep 10 - eps2.8_h1dden-pr0cess.axx [Release date:: 2016-09-07]
- [x] Ep 9 - eps2.7_init5.fve [Release date:: 2016-08-31]
- [x] Ep 8 - eps2.6_succ3ss0r.p12 [Release date:: 2016-08-24]
- [x] Ep 7 - eps2.5_h4ndshake.sme [Release date:: 2016-08-17]
- [x] Ep 6 - eps2.4_m4ster-s1ave.aes [Release date:: 2016-08-10]
- [x] Ep 5 - eps2.3_logic-b0mb.hc [Release date:: 2016-08-03]
- [x] Ep 4 - eps2.2_init1.asec [Release date:: 2016-07-27]
- [x] Ep 3 - eps2.1_k3rnel-pan1c.ksd [Release date:: 2016-07-20]
- [x] Ep 2 - eps2.0_unm4sk-pt2.tc [Release date:: 2016-07-13]
- [x] Ep 1 - eps2.0_unm4sk-pt1.tc [Release date:: 2016-07-13]

## Season 1
- [x] Ep 10 - eps1.9_zer0-day.avi [Release date:: 2015-09-02]
- [x] Ep 9 - eps1.8_m1rr0r1ng.qt [Release date:: 2015-08-19]
- [x] Ep 8 - eps1.7_wh1ter0se.m4v [Release date:: 2015-08-12]
- [x] Ep 7 - eps1.6_v1ew-s0urce.flv [Release date:: 2015-08-05]
- [x] Ep 6 - eps1.5_br4ve-trave1er.asf [Release date:: 2015-07-29]
- [x] Ep 5 - eps1.4_3xpl0its.wmv [Release date:: 2015-07-22]
- [x] Ep 4 - eps1.3_da3m0ns.mp4 [Release date:: 2015-07-15]
- [x] Ep 3 - eps1.2_d3bug.mkv [Release date:: 2015-07-08]
- [x] Ep 2 - eps1.1_ones-and-zer0es.mpeg [Release date:: 2015-07-01]
- [x] Ep 1 - eps1.0_hellofriend.mov [Release date:: 2015-06-24]


