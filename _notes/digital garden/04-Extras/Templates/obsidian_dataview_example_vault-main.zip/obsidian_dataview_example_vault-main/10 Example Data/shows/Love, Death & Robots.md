---
Title: Love, Death & Robots
Genre: ['Horror', 'Science-Fiction', 'Thriller']
Network: Netflix

Seasons: 3
Episodes: 35
Runtime: 13
Show_status: To Be Determined

Status: 'Stopped watching'
Rating: 
Would rewatch: 
---

## Season 3
- [ ] Ep 9 - Jibaro [Release date:: 2022-05-20]
- [ ] Ep 8 - In Vaulted Halls Entombed [Release date:: 2022-05-20]
- [ ] Ep 7 - Mason's Rats [Release date:: 2022-05-20]
- [ ] Ep 6 - Swarm [Release date:: 2022-05-20]
- [ ] Ep 5 - Kill Team Kill [Release date:: 2022-05-20]
- [ ] Ep 4 - Night of the Mini Dead [Release date:: 2022-05-20]
- [ ] Ep 3 - The Very Pulse of the Machine [Release date:: 2022-05-20]
- [ ] Ep 2 - Bad Travelling [Release date:: 2022-05-20]
- [ ] Ep 1 - Three Robots: Exit Strategies [Release date:: 2022-05-20]

## Season 2
- [ ] Ep 8 - The Drowned Giant [Release date:: 2021-05-14]
- [ ] Ep 7 - Life Hutch [Release date:: 2021-05-14]
- [ ] Ep 6 - All Through the House [Release date:: 2021-05-14]
- [ ] Ep 5 - The Tall Grass [Release date:: 2021-05-14]
- [ ] Ep 4 - Snow in the Desert [Release date:: 2021-05-14]
- [ ] Ep 3 - Pop Squad [Release date:: 2021-05-14]
- [ ] Ep 2 - Ice [Release date:: 2021-05-14]
- [ ] Ep 1 - Automated Customer Service [Release date:: 2021-05-14]

## Season 1
- [x] Ep 18 - Zima Blue [Release date:: 2019-03-15]
- [x] Ep 17 - Blindspot [Release date:: 2019-03-15]
- [x] Ep 16 - Lucky 13 [Release date:: 2019-03-15]
- [x] Ep 15 - Alternate Histories [Release date:: 2019-03-15]
- [x] Ep 14 - Helping Hand [Release date:: 2019-03-15]
- [x] Ep 13 - Fish Night [Release date:: 2019-03-15]
- [x] Ep 12 - Shape-Shifters [Release date:: 2019-03-15]
- [x] Ep 11 - The Dump [Release date:: 2019-03-15]
- [x] Ep 10 - Good Hunting [Release date:: 2019-03-15]
- [x] Ep 9 - Suits [Release date:: 2019-03-15]
- [x] Ep 8 - The Witness [Release date:: 2019-03-15]
- [x] Ep 7 - Sucker of Souls [Release date:: 2019-03-15]
- [x] Ep 6 - The Secret War [Release date:: 2019-03-15]
- [x] Ep 5 - When the Yogurt Took Over [Release date:: 2019-03-15]
- [x] Ep 4 - Sonnie's Edge [Release date:: 2019-03-15]
- [x] Ep 3 - Ice Age [Release date:: 2019-03-15]
- [x] Ep 2 - Beyond the Aquila Rift [Release date:: 2019-03-15]
- [x] Ep 1 - Three Robots [Release date:: 2019-03-15]


