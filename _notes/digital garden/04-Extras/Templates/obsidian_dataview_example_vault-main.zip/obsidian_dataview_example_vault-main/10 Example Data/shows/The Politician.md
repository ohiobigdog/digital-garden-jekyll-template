---
Title: The Politician
Genre: ['Drama', 'Comedy']
Network: Netflix

Seasons: 2
Episodes: 15
Runtime: 44
Show_status: Ended

Status: 'Watched all'
Rating: 5/5
Would rewatch: 
---

## Season 2
- [x] Ep 7 - Election Day [Release date:: 2020-06-19]
- [x] Ep 6 - What's in the Box? [Release date:: 2020-06-19]
- [x] Ep 5 - The Voters [Release date:: 2020-06-19]
- [x] Ep 4 - Hail Mary [Release date:: 2020-06-19]
- [x] Ep 3 - Cancel Culture [Release date:: 2020-06-19]
- [x] Ep 2 - Conscious Unthroupling [Release date:: 2020-06-19]
- [x] Ep 1 - New York State of Mind [Release date:: 2020-06-19]

## Season 1
- [x] Ep 8 - Vienna [Release date:: 2019-09-27]
- [x] Ep 7 - The Assassination of Payton Hobart: Part 2 [Release date:: 2019-09-27]
- [x] Ep 6 - The Assassination of Payton Hobart [Release date:: 2019-09-27]
- [x] Ep 5 - The Voter [Release date:: 2019-09-27]
- [x] Ep 4 - Gone Girl [Release date:: 2019-09-27]
- [x] Ep 3 - October Surprise [Release date:: 2019-09-27]
- [x] Ep 2 - The Harrington Commode [Release date:: 2019-09-27]
- [x] Ep 1 - Pilot [Release date:: 2019-09-27]


