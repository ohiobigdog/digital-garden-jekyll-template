---
Title: Horace and Pete
Genre: ['Drama', 'Comedy']
Network: LouisCK.net

Seasons: 1
Episodes: 10
Runtime: 44
Show_status: Ended

Status: 'Watched all'
Rating: 5/5
Would rewatch: 
---

## Season 1
- [x] Ep 10 - Episode 10 [Release date:: 2016-04-02]
- [x] Ep 9 - Episode 9 [Release date:: 2016-03-26]
- [x] Ep 8 - Episode 8 [Release date:: 2016-03-19]
- [x] Ep 7 - Episode 7 [Release date:: 2016-03-12]
- [x] Ep 6 - Episode 6 [Release date:: 2016-03-05]
- [x] Ep 5 - Episode 5 [Release date:: 2016-02-27]
- [x] Ep 4 - Episode 4 [Release date:: 2016-02-20]
- [x] Ep 3 - Episode 3 [Release date:: 2016-02-13]
- [x] Ep 2 - Episode 2 [Release date:: 2016-02-06]
- [x] Ep 1 - Episode 1 [Release date:: 2016-01-30]


