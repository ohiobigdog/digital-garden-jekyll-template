---
Title: Happy!
Genre: ['Drama', 'Crime', 'Fantasy']
Network: Syfy

Seasons: 2
Episodes: 18
Runtime: 60
Show_status: Ended

Status: 'Watched all'
Rating: 5/5
Would rewatch: 
---

## Season 2
- [x] Ep 10 - Resurrection [Release date:: 2019-05-29]
- [x] Ep 9 - Five Chicken Fingers and a Gun [Release date:: 2019-05-22]
- [x] Ep 8 - A Friend of Death [Release date:: 2019-05-15]
- [x] Ep 7 - Arlo and Marie [Release date:: 2019-05-08]
- [x] Ep 6 - Pervapalooza [Release date:: 2019-05-01]
- [x] Ep 5 - 19 Hours and 13 Minutes [Release date:: 2019-04-24]
- [x] Ep 4 - Blitzkrieg!!! [Release date:: 2019-04-17]
- [x] Ep 3 - Some Girls Need a Lot of Repenting [Release date:: 2019-04-10]
- [x] Ep 2 - Tallahassee [Release date:: 2019-04-03]
- [x] Ep 1 - The War on Easter [Release date:: 2019-03-27]

## Season 1
- [x] Ep 8 - I Am the Future [Release date:: 2018-01-31]
- [x] Ep 7 - Destroyer of Worlds [Release date:: 2018-01-24]
- [x] Ep 6 - The Scrapyard of Childish Things [Release date:: 2018-01-17]
- [x] Ep 5 - White Sauce? Hot Sauce? [Release date:: 2018-01-10]
- [x] Ep 4 - Year of the Horse [Release date:: 2017-12-27]
- [x] Ep 3 - When Christmas Was Christmas [Release date:: 2017-12-20]
- [x] Ep 2 - What Smiles Are For [Release date:: 2017-12-13]
- [x] Ep 1 - Saint Nick [Release date:: 2017-12-06]


