---
Title: Black Sails
Genre: ['Drama', 'Action', 'Adventure']
Network: STARZ

Seasons: 4
Episodes: 38
Runtime: 60
Show_status: Ended

Status: 'Watched all'
Rating: 3/5
Would rewatch: 
---

## Season 4
- [x] Ep 10 - XXXVIII. [Release date:: 2017-04-02]
- [x] Ep 9 - XXXVII. [Release date:: 2017-03-26]
- [x] Ep 8 - XXXVI. [Release date:: 2017-03-19]
- [x] Ep 7 - XXXV. [Release date:: 2017-03-12]
- [x] Ep 6 - XXXIV. [Release date:: 2017-03-05]
- [x] Ep 5 - XXXIII. [Release date:: 2017-02-26]
- [x] Ep 4 - XXXII. [Release date:: 2017-02-19]
- [x] Ep 3 - XXXI. [Release date:: 2017-02-12]
- [x] Ep 2 - XXX. [Release date:: 2017-02-05]
- [x] Ep 1 - XXIX. [Release date:: 2017-01-29]

## Season 3
- [x] Ep 10 - XXVIII. [Release date:: 2016-03-26]
- [x] Ep 9 - XXVII. [Release date:: 2016-03-19]
- [x] Ep 8 - XXVI. [Release date:: 2016-03-12]
- [x] Ep 7 - XXV. [Release date:: 2016-03-05]
- [x] Ep 6 - XXIV. [Release date:: 2016-02-27]
- [x] Ep 5 - XXIII. [Release date:: 2016-02-20]
- [x] Ep 4 - XXII. [Release date:: 2016-02-13]
- [x] Ep 3 - XXI. [Release date:: 2016-02-06]
- [x] Ep 2 - XX. [Release date:: 2016-01-30]
- [x] Ep 1 - XIX. [Release date:: 2016-01-23]

## Season 2
- [x] Ep 10 - XVIII. [Release date:: 2015-03-28]
- [x] Ep 9 - XVII. [Release date:: 2015-03-21]
- [x] Ep 8 - XVI. [Release date:: 2015-03-14]
- [x] Ep 7 - XV. [Release date:: 2015-03-07]
- [x] Ep 6 - XIV. [Release date:: 2015-02-28]
- [x] Ep 5 - XIII. [Release date:: 2015-02-21]
- [x] Ep 4 - XII. [Release date:: 2015-02-14]
- [x] Ep 3 - XI. [Release date:: 2015-02-07]
- [x] Ep 2 - X. [Release date:: 2015-01-31]
- [x] Ep 1 - IX. [Release date:: 2015-01-24]

## Season 1
- [x] Ep 8 - VIII. [Release date:: 2014-03-15]
- [x] Ep 7 - VII. [Release date:: 2014-03-08]
- [x] Ep 6 - VI. [Release date:: 2014-03-01]
- [x] Ep 5 - V. [Release date:: 2014-02-22]
- [x] Ep 4 - IV. [Release date:: 2014-02-15]
- [x] Ep 3 - III. [Release date:: 2014-02-08]
- [x] Ep 2 - II. [Release date:: 2014-02-01]
- [x] Ep 1 - I. [Release date:: 2014-01-25]


