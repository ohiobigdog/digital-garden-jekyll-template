---
Title: American Crime Story
Genre: ['Drama', 'Crime']
Network: FX

Seasons: 4
Episodes: 29
Runtime: 69
Show_status: Running

Status: 'Watched all'
Rating: 5/5
Would rewatch: 
---

## Season 4

## Season 3
- [x] Ep 10 - The Wilderness [Release date:: 2021-11-09]
- [x] Ep 9 - The Grand Jury [Release date:: 2021-11-02]
- [x] Ep 8 - Stand by Your Man [Release date:: 2021-10-26]
- [x] Ep 7 - The Assassination of Monica Lewinsky [Release date:: 2021-10-19]
- [x] Ep 6 - Man Handled [Release date:: 2021-10-12]
- [x] Ep 5 - Do You Hear What I Hear? [Release date:: 2021-10-05]
- [x] Ep 4 - The Telephone Hour [Release date:: 2021-09-28]
- [x] Ep 3 - Not to Be Believed [Release date:: 2021-09-21]
- [x] Ep 2 - The President Kissed Me [Release date:: 2021-09-14]
- [x] Ep 1 - Exiles [Release date:: 2021-09-07]

## Season 2
- [x] Ep 9 - Alone [Release date:: 2018-03-21]
- [x] Ep 8 - Creator / Destroyer [Release date:: 2018-03-14]
- [x] Ep 7 - Ascent [Release date:: 2018-03-07]
- [x] Ep 6 - Descent [Release date:: 2018-02-28]
- [x] Ep 5 - Don't Ask Don't Tell [Release date:: 2018-02-14]
- [x] Ep 4 - House By the Lake [Release date:: 2018-02-07]
- [x] Ep 3 - A Random Killing [Release date:: 2018-01-31]
- [x] Ep 2 - Manhunt [Release date:: 2018-01-24]
- [x] Ep 1 - The Man Who Would Be Vogue [Release date:: 2018-01-17]

## Season 1
- [x] Ep 10 - The Verdict [Release date:: 2016-04-05]
- [x] Ep 9 - Manna from Heaven [Release date:: 2016-03-29]
- [x] Ep 8 - A Jury in Jail [Release date:: 2016-03-22]
- [x] Ep 7 - Conspiracy Theories [Release date:: 2016-03-15]
- [x] Ep 6 - Marcia, Marcia, Marcia [Release date:: 2016-03-08]
- [x] Ep 5 - The Race Card [Release date:: 2016-03-01]
- [x] Ep 4 - 100% Not Guilty [Release date:: 2016-02-23]
- [x] Ep 3 - The Dream Team [Release date:: 2016-02-16]
- [x] Ep 2 - The Run of His Life [Release date:: 2016-02-09]
- [x] Ep 1 - From the Ashes of Tragedy [Release date:: 2016-02-02]


