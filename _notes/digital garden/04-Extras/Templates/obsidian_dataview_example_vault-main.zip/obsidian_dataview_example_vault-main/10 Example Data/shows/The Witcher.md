---
Title: The Witcher
Genre: ['Drama', 'Action', 'Fantasy']
Network: Netflix

Seasons: 2
Episodes: 16
Runtime: 58
Show_status: Running

Status: 'Watching'
Rating: 
Would rewatch: 
---

## Season 2
- [ ] Ep 8 - Family [Release date:: 2021-12-17]
- [ ] Ep 7 - Voleth Meir [Release date:: 2021-12-17]
- [ ] Ep 6 - Dear Friend... [Release date:: 2021-12-17]
- [ ] Ep 5 - Turn Your Back [Release date:: 2021-12-17]
- [ ] Ep 4 - Redanian Intelligence [Release date:: 2021-12-17]
- [ ] Ep 3 - What Is Lost [Release date:: 2021-12-17]
- [ ] Ep 2 - Kaer Morhen [Release date:: 2021-12-17]
- [ ] Ep 1 - A Grain of Truth [Release date:: 2021-12-17]

## Season 1
- [ ] Ep 8 - Much More [Release date:: 2019-12-20]
- [ ] Ep 7 - Before a Fall [Release date:: 2019-12-20]
- [ ] Ep 6 - Rare Species [Release date:: 2019-12-20]
- [x] Ep 5 - Bottled Appetites [Release date:: 2019-12-20]
- [x] Ep 4 - Of Banquets, Bastards and Burials [Release date:: 2019-12-20]
- [x] Ep 3 - Betrayer Moon [Release date:: 2019-12-20]
- [x] Ep 2 - Four Marks [Release date:: 2019-12-20]
- [x] Ep 1 - The End's Beginning [Release date:: 2019-12-20]


