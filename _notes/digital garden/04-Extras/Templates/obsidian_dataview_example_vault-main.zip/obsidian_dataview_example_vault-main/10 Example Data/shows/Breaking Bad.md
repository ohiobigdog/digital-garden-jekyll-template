---
Title: Breaking Bad
Genre: ['Drama', 'Crime', 'Thriller']
Network: AMC

Seasons: 5
Episodes: 62
Runtime: 60
Show_status: Ended

Status: 'Watched all'
Rating: 5/5
Would rewatch: 
---

## Season 5
- [x] Ep 16 - Felina [Release date:: 2013-09-29]
- [x] Ep 15 - Granite State [Release date:: 2013-09-22]
- [x] Ep 14 - Ozymandias [Release date:: 2013-09-15]
- [x] Ep 13 - To'hajiilee [Release date:: 2013-09-08]
- [x] Ep 12 - Rabid Dog [Release date:: 2013-09-01]
- [x] Ep 11 - Confessions [Release date:: 2013-08-25]
- [x] Ep 10 - Buried [Release date:: 2013-08-18]
- [x] Ep 9 - Blood Money [Release date:: 2013-08-11]
- [x] Ep 8 - Gliding Over All [Release date:: 2012-09-02]
- [x] Ep 7 - Say My Name [Release date:: 2012-08-26]
- [x] Ep 6 - Buyout [Release date:: 2012-08-19]
- [x] Ep 5 - Dead Freight [Release date:: 2012-08-12]
- [x] Ep 4 - Fifty-One [Release date:: 2012-08-05]
- [x] Ep 3 - Hazard Pay [Release date:: 2012-07-29]
- [x] Ep 2 - Madrigal [Release date:: 2012-07-22]
- [x] Ep 1 - Live Free or Die [Release date:: 2012-07-15]

## Season 4
- [x] Ep 13 - Face Off [Release date:: 2011-10-09]
- [x] Ep 12 - End Times [Release date:: 2011-10-02]
- [x] Ep 11 - Crawl Space [Release date:: 2011-09-25]
- [x] Ep 10 - Salud [Release date:: 2011-09-18]
- [x] Ep 9 - Bug [Release date:: 2011-09-11]
- [x] Ep 8 - Hermanos [Release date:: 2011-09-04]
- [x] Ep 7 - Problem Dog [Release date:: 2011-08-28]
- [x] Ep 6 - Cornered [Release date:: 2011-08-21]
- [x] Ep 5 - Shotgun [Release date:: 2011-08-14]
- [x] Ep 4 - Bullet Points [Release date:: 2011-08-07]
- [x] Ep 3 - Open House [Release date:: 2011-07-31]
- [x] Ep 2 - Thirty-Eight Snub [Release date:: 2011-07-24]
- [x] Ep 1 - Box Cutter [Release date:: 2011-07-17]

## Season 3
- [x] Ep 13 - Full Measure [Release date:: 2010-06-13]
- [x] Ep 12 - Half Measures [Release date:: 2010-06-06]
- [x] Ep 11 - Abiquiu [Release date:: 2010-05-30]
- [x] Ep 10 - Fly [Release date:: 2010-05-23]
- [x] Ep 9 - Kafkaesque [Release date:: 2010-05-16]
- [x] Ep 8 - I See You [Release date:: 2010-05-09]
- [x] Ep 7 - One Minute [Release date:: 2010-05-02]
- [x] Ep 6 - Sunset [Release date:: 2010-04-25]
- [x] Ep 5 - M�s [Release date:: 2010-04-18]
- [x] Ep 4 - Green Light [Release date:: 2010-04-11]
- [x] Ep 3 - I.F.T. [Release date:: 2010-04-04]
- [x] Ep 2 - Caballo sin Nombre [Release date:: 2010-03-28]
- [x] Ep 1 - No M�s [Release date:: 2010-03-21]

## Season 2
- [x] Ep 13 - ABQ [Release date:: 2009-05-31]
- [x] Ep 12 - Phoenix [Release date:: 2009-05-24]
- [x] Ep 11 - Mandala [Release date:: 2009-05-17]
- [x] Ep 10 - Over [Release date:: 2009-05-10]
- [x] Ep 9 - 4 Days Out [Release date:: 2009-05-03]
- [x] Ep 8 - Better Call Saul [Release date:: 2009-04-26]
- [x] Ep 7 - Negro Y Azul [Release date:: 2009-04-19]
- [x] Ep 6 - Peekaboo [Release date:: 2009-04-12]
- [x] Ep 5 - Breakage [Release date:: 2009-04-05]
- [x] Ep 4 - Down [Release date:: 2009-03-29]
- [x] Ep 3 - Bit by a Dead Bee [Release date:: 2009-03-22]
- [x] Ep 2 - Grilled [Release date:: 2009-03-15]
- [x] Ep 1 - Seven Thirty-Seven [Release date:: 2009-03-08]

## Season 1
- [x] Ep 7 - A No-Rough-Stuff-Type Deal [Release date:: 2008-03-09]
- [x] Ep 6 - Crazy Handful of Nothin' [Release date:: 2008-03-02]
- [x] Ep 5 - Gray Matter [Release date:: 2008-02-24]
- [x] Ep 4 - Cancer Man [Release date:: 2008-02-17]
- [x] Ep 3 - ...and the Bag's in the River [Release date:: 2008-02-10]
- [x] Ep 2 - Cat's in the Bag... [Release date:: 2008-01-27]
- [x] Ep 1 - Pilot [Release date:: 2008-01-20]


