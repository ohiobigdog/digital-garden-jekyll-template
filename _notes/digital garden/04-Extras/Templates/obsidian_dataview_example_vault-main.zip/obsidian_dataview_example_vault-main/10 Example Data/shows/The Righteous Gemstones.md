---
Title: The Righteous Gemstones
Genre: ['Comedy']
Network: HBO

Seasons: 2
Episodes: 18
Runtime: 38
Show_status: Running

Status: 'Going to watch'
Rating: 
Would rewatch: 
---

## Season 2
- [ ] Ep 9 - I Will Tell of All Your Deeds [Release date:: 2022-02-27]
- [ ] Ep 8 - The Prayer of a Righteous Man [Release date:: 2022-02-20]
- [ ] Ep 7 - And Infants Shall Rule Over Them [Release date:: 2022-02-13]
- [ ] Ep 6 - Never Avenge Yourselves, But Leave It to the Wrath of God [Release date:: 2022-02-06]
- [ ] Ep 5 - Interlude II [Release date:: 2022-01-30]
- [ ] Ep 4 - As to How They Might Destroy Him [Release date:: 2022-01-23]
- [ ] Ep 3 - For He Is a Liar and the Father of Lies [Release date:: 2022-01-16]
- [ ] Ep 2 - After I Leave, Savage Wolves Will Come [Release date:: 2022-01-09]
- [ ] Ep 1 - I Speak in the Tongues of Men and Angels [Release date:: 2022-01-09]

## Season 1
- [ ] Ep 9 - Better is the End of a Thing Than Its Beginning [Release date:: 2019-10-13]
- [ ] Ep 8 - But the Righteous Will See Their Fall [Release date:: 2019-10-06]
- [ ] Ep 7 - And Yet One of You is a Devil [Release date:: 2019-09-29]
- [ ] Ep 6 - Now the Sons of Eli Were Worthless Men [Release date:: 2019-09-22]
- [ ] Ep 5 - Interlude [Release date:: 2019-09-15]
- [ ] Ep 4 - Wicked Lips [Release date:: 2019-09-08]
- [ ] Ep 3 - They Are Weak, But He Is Strong [Release date:: 2019-09-01]
- [ ] Ep 2 - Is This the Man Who Made the Earth Tremble [Release date:: 2019-08-25]
- [ ] Ep 1 - The Righteous Gemstones [Release date:: 2019-08-18]


