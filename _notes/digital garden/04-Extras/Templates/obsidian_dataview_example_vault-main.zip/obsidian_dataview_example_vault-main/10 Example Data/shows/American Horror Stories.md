
---
Title: American Horror Stories
Genre: ['Horror']
Network: Hulu

Seasons: 2
Episodes: 15
Runtime: 44
Show_status: Running

Status: 'Watching'
Rating: 2/5
Would rewatch: false 
---

## Season 2
- [ ] Ep 8 - Lake [Release date:: 2022-09-08]
- [ ] Ep 7 - Milkmaids [Release date:: 2022-09-01]
- [ ] Ep 6 - Facelift [Release date:: 2022-08-25]
- [ ] Ep 5 - Bloody Mary [Release date:: 2022-08-18]
- [ ] Ep 4 - Drive [Release date:: 2022-08-11]
- [ ] Ep 3 - Necro [Release date:: 2022-08-04]
- [ ] Ep 2 - Aura [Release date:: 2022-07-28]
- [ ] Ep 1 - Dollhouse [Release date:: 2022-07-21]

## Season 1
- [x] Ep 7 - Game Over [Release date:: 2021-08-19]
- [x] Ep 6 - Feral [Release date:: 2021-08-12]
- [x] Ep 5 - BA'AL [Release date:: 2021-08-05]
- [x] Ep 4 - The Naughty List [Release date:: 2021-07-29]
- [x] Ep 3 - Drive In [Release date:: 2021-07-22]
- [x] Ep 2 - Rubber(wo)Man Part Two [Release date:: 2021-07-15]
- [x] Ep 1 - Rubber(wo)Man [Release date:: 2021-07-15]


