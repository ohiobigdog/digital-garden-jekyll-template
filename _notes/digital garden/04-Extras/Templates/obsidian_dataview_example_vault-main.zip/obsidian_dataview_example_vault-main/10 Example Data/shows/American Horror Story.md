
---
Title: American Horror Story
Genre: ['Drama', 'Horror', 'Thriller']
Network: FX

Seasons: 13
Episodes: 116
Runtime: 61
Show_status: Running

Status: 'Watching'
Rating: 4/5
Would rewatch: true
---

## Season 13

## Season 12

## Season 11
- [ ] Ep 3 - Thank You For Your Service [Release date:: 2022-10-24]
- [ ] Ep 2 - Smoke Signals [Release date:: 2022-10-17]
- [ ] Ep 1 - Something's Coming [Release date:: 2022-10-17]

## Season 10
- [ ] Ep 10 - The Future Perfect [Release date:: 2021-10-20]
- [ ] Ep 9 - Blue Moon [Release date:: 2021-10-13]
- [ ] Ep 8 - Inside [Release date:: 2021-10-06]
- [ ] Ep 7 - Take Me to Your Leader [Release date:: 2021-09-29]
- [ ] Ep 6 - Winter Kills [Release date:: 2021-09-22]
- [ ] Ep 5 - Gaslight [Release date:: 2021-09-15]
- [ ] Ep 4 - Blood Buffet [Release date:: 2021-09-08]
- [ ] Ep 3 - Thirst [Release date:: 2021-09-01]
- [ ] Ep 2 - Pale [Release date:: 2021-08-25]
- [ ] Ep 1 - Cape Fear [Release date:: 2021-08-25]

## Season 9
- [ ] Ep 9 - Final Girl [Release date:: 2019-11-13]
- [ ] Ep 8 - Rest in Pieces [Release date:: 2019-11-06]
- [ ] Ep 7 - The Lady in White [Release date:: 2019-10-30]
- [ ] Ep 6 - Episode 100 [Release date:: 2019-10-23]
- [ ] Ep 5 - Red Dawn [Release date:: 2019-10-16]
- [ ] Ep 4 - True Killers [Release date:: 2019-10-09]
- [ ] Ep 3 - Slashdance [Release date:: 2019-10-02]
- [ ] Ep 2 - Mr. Jingles [Release date:: 2019-09-25]
- [ ] Ep 1 - Camp Redwood [Release date:: 2019-09-18]

## Season 8
- [x] Ep 10 - Apocalypse Then [Release date:: 2018-11-14]
- [x] Ep 9 - Fire and Reign [Release date:: 2018-11-07]
- [x] Ep 8 - Sojourn [Release date:: 2018-10-31]
- [x] Ep 7 - Traitor [Release date:: 2018-10-24]
- [x] Ep 6 - Return to Murder House [Release date:: 2018-10-17]
- [x] Ep 5 - Boy Wonder [Release date:: 2018-10-10]
- [x] Ep 4 - Could It Be ... Satan? [Release date:: 2018-10-03]
- [x] Ep 3 - Forbidden Fruit [Release date:: 2018-09-26]
- [x] Ep 2 - The Morning After [Release date:: 2018-09-19]
- [x] Ep 1 - The End [Release date:: 2018-09-12]

## Season 7
- [x] Ep 11 - Great Again [Release date:: 2017-11-14]
- [x] Ep 10 - Charles (Manson) in Charge [Release date:: 2017-11-07]
- [x] Ep 9 - Drink the Kool-Aid [Release date:: 2017-10-31]
- [x] Ep 8 - Winter of Our Discontent [Release date:: 2017-10-24]
- [x] Ep 7 - Valerie Solanas Died for Your Sins: Scumbag [Release date:: 2017-10-17]
- [x] Ep 6 - Mid-Western Assassin [Release date:: 2017-10-10]
- [x] Ep 5 - Holes [Release date:: 2017-10-03]
- [x] Ep 4 - 11/9 [Release date:: 2017-09-26]
- [x] Ep 3 - Neighbors from Hell [Release date:: 2017-09-19]
- [x] Ep 2 - Don't Be Afraid of the Dark [Release date:: 2017-09-12]
- [x] Ep 1 - Election Night [Release date:: 2017-09-05]

## Season 6
- [ ] Ep 10 - Chapter 10 [Release date:: 2016-11-16]
- [ ] Ep 9 - Chapter 9 [Release date:: 2016-11-09]
- [ ] Ep 8 - Chapter 8 [Release date:: 2016-11-02]
- [ ] Ep 7 - Chapter 7 [Release date:: 2016-10-26]
- [ ] Ep 6 - Chapter 6 [Release date:: 2016-10-19]
- [ ] Ep 5 - Chapter 5 [Release date:: 2016-10-12]
- [ ] Ep 4 - Chapter 4 [Release date:: 2016-10-05]
- [ ] Ep 3 - Chapter 3 [Release date:: 2016-09-28]
- [ ] Ep 2 - Chapter 2 [Release date:: 2016-09-21]
- [ ] Ep 1 - Chapter 1 [Release date:: 2016-09-14]

## Season 5
- [ ] Ep 12 - Be Our Guest [Release date:: 2016-01-13]
- [ ] Ep 11 - Battle Royale [Release date:: 2016-01-06]
- [ ] Ep 10 - She Gets Revenge [Release date:: 2015-12-16]
- [ ] Ep 9 - She Wants Revenge [Release date:: 2015-12-09]
- [ ] Ep 8 - The Ten Commandments Killer [Release date:: 2015-12-02]
- [ ] Ep 7 - Flicker [Release date:: 2015-11-18]
- [ ] Ep 6 - Room 33 [Release date:: 2015-11-11]
- [ ] Ep 5 - Room Service [Release date:: 2015-11-04]
- [ ] Ep 4 - Devil's Night [Release date:: 2015-10-28]
- [ ] Ep 3 - Mommy [Release date:: 2015-10-21]
- [ ] Ep 2 - Chutes and Ladders [Release date:: 2015-10-14]
- [ ] Ep 1 - Checking In [Release date:: 2015-10-07]

## Season 4
- [x] Ep 13 - Curtain Call [Release date:: 2015-01-21]
- [x] Ep 12 - Show Stoppers [Release date:: 2015-01-14]
- [x] Ep 11 - Magical Thinking [Release date:: 2015-01-07]
- [x] Ep 10 - Orphans [Release date:: 2014-12-17]
- [x] Ep 9 - Tupperware Party Massacre [Release date:: 2014-12-10]
- [x] Ep 8 - Blood Bath [Release date:: 2014-12-03]
- [x] Ep 7 - Test of Strength [Release date:: 2014-11-19]
- [x] Ep 6 - Bullseye [Release date:: 2014-11-12]
- [x] Ep 5 - Pink Cupcakes [Release date:: 2014-11-05]
- [x] Ep 4 - Edward Mordrake: Part 2 [Release date:: 2014-10-29]
- [x] Ep 3 - Edward Mordrake: Part 1 [Release date:: 2014-10-22]
- [x] Ep 2 - Massacres and Matinees [Release date:: 2014-10-15]
- [x] Ep 1 - Monsters Among Us [Release date:: 2014-10-08]

## Season 3
- [x] Ep 13 - The Seven Wonders [Release date:: 2014-01-29]
- [x] Ep 12 - Go to Hell [Release date:: 2014-01-22]
- [x] Ep 11 - Protect the Coven [Release date:: 2014-01-15]
- [x] Ep 10 - The Magical Delights of Stevie Nicks [Release date:: 2014-01-08]
- [x] Ep 9 - Head [Release date:: 2013-12-11]
- [x] Ep 8 - The Sacred Taking [Release date:: 2013-12-04]
- [x] Ep 7 - The Dead [Release date:: 2013-11-20]
- [x] Ep 6 - The Axeman Cometh [Release date:: 2013-11-13]
- [x] Ep 5 - Burn, Witch. Burn! [Release date:: 2013-11-06]
- [x] Ep 4 - Fearful Pranks Ensue [Release date:: 2013-10-30]
- [x] Ep 3 - The Replacements [Release date:: 2013-10-23]
- [x] Ep 2 - Boy Parts [Release date:: 2013-10-16]
- [x] Ep 1 - Bitchcraft [Release date:: 2013-10-09]

## Season 2
- [x] Ep 13 - Madness Ends [Release date:: 2013-01-23]
- [x] Ep 12 - Continuum [Release date:: 2013-01-16]
- [x] Ep 11 - Spilt Milk [Release date:: 2013-01-09]
- [x] Ep 10 - The Name Game [Release date:: 2013-01-02]
- [x] Ep 9 - The Coat Hanger [Release date:: 2012-12-12]
- [x] Ep 8 - Unholy Night [Release date:: 2012-12-05]
- [x] Ep 7 - Dark Cousin [Release date:: 2012-11-28]
- [x] Ep 6 - The Origins of Monstrosity [Release date:: 2012-11-21]
- [x] Ep 5 - I Am Anne Frank Part 2 [Release date:: 2012-11-14]
- [x] Ep 4 - I Am Anne Frank Part 1 [Release date:: 2012-11-07]
- [x] Ep 3 - Nor'easter [Release date:: 2012-10-31]
- [x] Ep 2 - Tricks and Treats [Release date:: 2012-10-24]
- [x] Ep 1 - Welcome to Briarcliff [Release date:: 2012-10-17]

## Season 1
- [x] Ep 12 - Afterbirth [Release date:: 2011-12-21]
- [x] Ep 11 - Birth [Release date:: 2011-12-14]
- [x] Ep 10 - Smoldering Children [Release date:: 2011-12-07]
- [x] Ep 9 - Spooky Little Girl [Release date:: 2011-11-30]
- [x] Ep 8 - Rubber Man [Release date:: 2011-11-23]
- [x] Ep 7 - Open House [Release date:: 2011-11-16]
- [x] Ep 6 - Piggy, Piggy [Release date:: 2011-11-09]
- [x] Ep 5 - Halloween Part 2 [Release date:: 2011-11-02]
- [x] Ep 4 - Halloween Part 1 [Release date:: 2011-10-26]
- [x] Ep 3 - Murder House [Release date:: 2011-10-19]
- [x] Ep 2 - Home Invasion [Release date:: 2011-10-12]
- [x] Ep 1 - Pilot [Release date:: 2011-10-05]


