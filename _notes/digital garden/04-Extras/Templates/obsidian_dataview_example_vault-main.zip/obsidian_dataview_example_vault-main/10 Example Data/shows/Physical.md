---
Title: Physical
Genre: ['Drama', 'Comedy']
Network: Apple TV+

Seasons: 2
Episodes: 20
Runtime: 29
Show_status: Running

Status: 'Watching'
Rating: 
Would rewatch: false
---

## Season 2
- [ ] Ep 10 - TBA [Release date:: 2022-08-05]
- [ ] Ep 9 - Don't You Want to Get Better [Release date:: 2022-07-29]
- [ ] Ep 8 - Don't You Run and Hide [Release date:: 2022-07-22]
- [ ] Ep 7 - Don't Try This at Home [Release date:: 2022-07-15]
- [ ] Ep 6 - Don't You Have Enough [Release date:: 2022-07-08]
- [ ] Ep 5 - Don't You Want to Watch [Release date:: 2022-07-01]
- [ ] Ep 4 - Don't You Know [Release date:: 2022-06-24]
- [ ] Ep 3 - Don't You Go Far [Release date:: 2022-06-17]
- [x] Ep 2 - Don't You Ever Stop [Release date:: 2022-06-10]
- [x] Ep 1 - Don't You Want Me [Release date:: 2022-06-03]

## Season 1
- [x] Ep 10 - Let's Get Together [Release date:: 2021-08-06]
- [x] Ep 9 - Let's Face the Facts [Release date:: 2021-07-30]
- [x] Ep 8 - Let's Not and Say We Did [Release date:: 2021-07-23]
- [x] Ep 7 - Let's Take This Show on the Road [Release date:: 2021-07-16]
- [x] Ep 6 - Let's Get It on Tape [Release date:: 2021-07-09]
- [x] Ep 5 - Let's Agree to Disagree [Release date:: 2021-07-02]
- [x] Ep 4 - Let's Get This Party Started [Release date:: 2021-06-25]
- [x] Ep 3 - Let's Get Down to Business [Release date:: 2021-06-18]
- [x] Ep 2 - Let's Get Political [Release date:: 2021-06-18]
- [x] Ep 1 - Let's Do This Thing [Release date:: 2021-06-18]

