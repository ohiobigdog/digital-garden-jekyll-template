---
Title: A.P. Bio
Genre: ['Comedy']
Network: Peacock

Seasons: 4
Episodes: 42
Runtime: 28
Show_status: Ended

Status: 'Watched all'
Rating: 3/5
Would rewatch: 
---

## Season 4
- [x] Ep 8 - The Harvard Pen [Release date:: 2021-09-02]
- [x] Ep 7 - Malachi [Release date:: 2021-09-02]
- [x] Ep 6 - Love, for Lack of a Better Term [Release date:: 2021-09-02]
- [x] Ep 5 - The Perfect Date from Hell [Release date:: 2021-09-02]
- [x] Ep 4 - Tons of Rue [Release date:: 2021-09-02]
- [x] Ep 3 - An Oath to Rusty [Release date:: 2021-09-02]
- [x] Ep 2 - Sweatpants [Release date:: 2021-09-02]
- [x] Ep 1 - Tornado! [Release date:: 2021-09-02]

## Season 3
- [x] Ep 8 - Katie Holmes Day [Release date:: 2020-09-03]
- [x] Ep 7 - Aces Wild [Release date:: 2020-09-03]
- [x] Ep 6 - That That That [Release date:: 2020-09-03]
- [x] Ep 5 - Mr. Pistachio [Release date:: 2020-09-03]
- [x] Ep 4 - Get Hoppy! [Release date:: 2020-09-03]
- [x] Ep 3 - Gary Meets Dave [Release date:: 2020-09-03]
- [x] Ep 2 - Disgraced [Release date:: 2020-09-03]
- [x] Ep 1 - Tiny Problems [Release date:: 2020-09-03]

## Season 2
- [x] Ep 13 - Kinda Sorta [Release date:: 2019-06-13]
- [x] Ep 12 - Ride the Ram [Release date:: 2019-06-13]
- [x] Ep 11 - Spectacle [Release date:: 2019-05-30]
- [x] Ep 10 - Handcuffed [Release date:: 2019-05-30]
- [x] Ep 9 - Dr. Whoopsie [Release date:: 2019-05-02]
- [x] Ep 8 - Sweet Low Road [Release date:: 2019-04-25]
- [x] Ep 7 - Personal Everest [Release date:: 2019-04-18]
- [x] Ep 6 - Melvin [Release date:: 2019-04-11]
- [x] Ep 5 - J'accuse [Release date:: 2019-04-04]
- [x] Ep 4 - Toledo's Top 100 [Release date:: 2019-03-28]
- [x] Ep 3 - Wednesday Morning, 8AM [Release date:: 2019-03-21]
- [x] Ep 2 - Nuns [Release date:: 2019-03-14]
- [x] Ep 1 - Happiness [Release date:: 2019-03-07]

## Season 1
- [x] Ep 13 - Drenching Dallas [Release date:: 2018-05-03]
- [x] Ep 12 - Walleye [Release date:: 2018-04-26]
- [x] Ep 11 - Eight Pigs and a Rat [Release date:: 2018-04-19]
- [x] Ep 10 - Durbin Crashes [Release date:: 2018-04-12]
- [x] Ep 9 - Rosemary's Boyfriend [Release date:: 2018-04-05]
- [x] Ep 8 - We Don't Party [Release date:: 2018-03-29]
- [x] Ep 7 - Selling Out [Release date:: 2018-03-22]
- [x] Ep 6 - Freakin' Enamored [Release date:: 2018-03-15]
- [x] Ep 5 - Dating Toledoans [Release date:: 2018-03-08]
- [x] Ep 4 - Burning Miles [Release date:: 2018-03-01]
- [x] Ep 3 - Overachieving Virgins [Release date:: 2018-03-01]
- [x] Ep 2 - Teacher Jail [Release date:: 2018-02-25]
- [x] Ep 1 - Catfish [Release date:: 2018-02-01]


