---
Title: Succession
Genre: ['Drama', 'Family']
Network: HBO

Seasons: 4
Episodes: 29
Runtime: 61
Show_status: Running

Status: 'Going to watch'
Rating: 
Would rewatch: 
---

## Season 4

## Season 3
- [ ] Ep 9 - All the Bells Say [Release date:: 2021-12-12]
- [ ] Ep 8 - Chiantishire [Release date:: 2021-12-05]
- [ ] Ep 7 - Too Much Birthday [Release date:: 2021-11-28]
- [ ] Ep 6 - What It Takes [Release date:: 2021-11-21]
- [ ] Ep 5 - Retired Janitors of Idaho [Release date:: 2021-11-14]
- [ ] Ep 4 - Lion in the Meadow [Release date:: 2021-11-07]
- [ ] Ep 3 - The Disruption [Release date:: 2021-10-31]
- [ ] Ep 2 - Mass in Time of War [Release date:: 2021-10-24]
- [ ] Ep 1 - Secession [Release date:: 2021-10-17]

## Season 2
- [ ] Ep 10 - This Is Not for Tears [Release date:: 2019-10-13]
- [ ] Ep 9 - DC [Release date:: 2019-10-06]
- [ ] Ep 8 - Dundee [Release date:: 2019-09-29]
- [ ] Ep 7 - Return [Release date:: 2019-09-22]
- [ ] Ep 6 - Argestes [Release date:: 2019-09-15]
- [ ] Ep 5 - Tern Haven [Release date:: 2019-09-08]
- [ ] Ep 4 - Safe Room [Release date:: 2019-09-01]
- [ ] Ep 3 - Hunting [Release date:: 2019-08-25]
- [ ] Ep 2 - Vaulter [Release date:: 2019-08-18]
- [ ] Ep 1 - The Summer Palace [Release date:: 2019-08-11]

## Season 1
- [ ] Ep 10 - Nobody Is Ever Missing [Release date:: 2018-08-05]
- [ ] Ep 9 - Pre-Nuptial [Release date:: 2018-07-29]
- [ ] Ep 8 - Prague [Release date:: 2018-07-22]
- [ ] Ep 7 - Austerlitz [Release date:: 2018-07-15]
- [ ] Ep 6 - Which Side Are You On? [Release date:: 2018-07-08]
- [ ] Ep 5 - I Went to Market [Release date:: 2018-07-01]
- [ ] Ep 4 - Sad Sack Wasp Trap [Release date:: 2018-06-24]
- [ ] Ep 3 - Lifeboats [Release date:: 2018-06-17]
- [ ] Ep 2 - Shit Show at the Fuck Factory [Release date:: 2018-06-10]
- [ ] Ep 1 - Celebration [Release date:: 2018-06-03]


