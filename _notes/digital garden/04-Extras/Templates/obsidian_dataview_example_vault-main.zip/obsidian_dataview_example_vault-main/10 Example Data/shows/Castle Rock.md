---
Title: Castle Rock
Genre: ['Drama', 'Horror', 'Thriller']
Network: Hulu

Seasons: 2
Episodes: 20
Runtime: 53
Show_status: Ended

Status: 'Stopped watching'
Rating: 
Would rewatch: 
---

## Season 2
- [ ] Ep 10 - Clean [Release date:: 2019-12-11]
- [ ] Ep 9 - Caveat Emptor [Release date:: 2019-12-04]
- [ ] Ep 8 - Dirty [Release date:: 2019-11-27]
- [ ] Ep 7 - The Word [Release date:: 2019-11-20]
- [ ] Ep 6 - The Mother [Release date:: 2019-11-13]
- [ ] Ep 5 - The Laughing Place [Release date:: 2019-11-06]
- [ ] Ep 4 - Restore Hope [Release date:: 2019-10-30]
- [ ] Ep 3 - Ties that Bind [Release date:: 2019-10-23]
- [ ] Ep 2 - New Jerusalem [Release date:: 2019-10-23]
- [ ] Ep 1 - Let the River Run [Release date:: 2019-10-23]

## Season 1
- [ ] Ep 10 - Romans [Release date:: 2018-09-12]
- [ ] Ep 9 - Henry Deaver [Release date:: 2018-09-05]
- [ ] Ep 8 - Past Perfect [Release date:: 2018-08-29]
- [ ] Ep 7 - The Queen [Release date:: 2018-08-22]
- [ ] Ep 6 - Filter [Release date:: 2018-08-15]
- [ ] Ep 5 - Harvest [Release date:: 2018-08-08]
- [ ] Ep 4 - The Box [Release date:: 2018-08-01]
- [ ] Ep 3 - Local Color [Release date:: 2018-07-25]
- [ ] Ep 2 - Habeas Corpus [Release date:: 2018-07-25]
- [x] Ep 1 - Severance [Release date:: 2018-07-25]


