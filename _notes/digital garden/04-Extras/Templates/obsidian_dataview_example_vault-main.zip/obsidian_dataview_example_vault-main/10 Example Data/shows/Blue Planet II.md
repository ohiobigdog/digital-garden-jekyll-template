---
Title: Blue Planet II
Genre: ['Nature']
Network: BBC One

Seasons: 1
Episodes: 7
Runtime: 58
Show_status: Ended

Status: 'Watched all'
Rating: 3/5
Would rewatch: 
---

## Season 1
- [x] Ep 7 - Our Blue Planet [Release date:: 2017-12-10]
- [x] Ep 6 - Coasts [Release date:: 2017-12-03]
- [x] Ep 5 - Green Seas [Release date:: 2017-11-26]
- [x] Ep 4 - Big Blue [Release date:: 2017-11-19]
- [x] Ep 3 - Coral Reefs [Release date:: 2017-11-12]
- [x] Ep 2 - The Deep [Release date:: 2017-11-05]
- [x] Ep 1 - One Ocean [Release date:: 2017-10-29]


