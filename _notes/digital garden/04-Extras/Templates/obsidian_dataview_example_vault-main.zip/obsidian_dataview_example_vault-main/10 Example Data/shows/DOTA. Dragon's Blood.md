---
Title: DOTA. Dragon's Blood
Genre: ['Action', 'Adventure', 'Anime', 'Fantasy']
Network: Netflix

Seasons: 3
Episodes: 17
Runtime: 26
Show_status: To Be Determined

Status: 'Stopped watching'
Rating: 
Would rewatch: 
---

## Season 3
- [ ] Ep 1 - Episode 1 [Release date:: 2022-08-11]

## Season 2
- [ ] Ep 8 - Chapter Eight: Unreal City [Release date:: 2022-01-18]
- [ ] Ep 7 - Chapter Seven: The Violet Hour [Release date:: 2022-01-18]
- [ ] Ep 6 - Chapter Six: The Hyacinth Girl [Release date:: 2022-01-18]
- [ ] Ep 5 - Chapter Five: The Burial of the Dead [Release date:: 2022-01-18]
- [ ] Ep 4 - Chapter Four: Desolate and Empty the Sea [Release date:: 2022-01-18]
- [ ] Ep 3 - Chapter Three: The Lady of Situations [Release date:: 2022-01-18]
- [ ] Ep 2 - Chapter Two: My Sword, My Life [Release date:: 2022-01-18]
- [ ] Ep 1 - Chapter One: Nothing with Nothing [Release date:: 2022-01-18]

## Season 1
- [x] Ep 8 - Chapter Eight: A Game of Chess [Release date:: 2021-03-25]
- [x] Ep 7 - Chapter Seven: Speak the Words [Release date:: 2021-03-25]
- [x] Ep 6 - Chapter Six: Knight, Death and the Devil [Release date:: 2021-03-25]
- [x] Ep 5 - Chapter Five: The Fire Sermon [Release date:: 2021-03-25]
- [x] Ep 4 - Chapter Four: The Monster at the End of This Book [Release date:: 2021-03-25]
- [x] Ep 3 - Chapter Three: Neverwhere Land [Release date:: 2021-03-25]
- [x] Ep 2 - Chapter Two: Princess of Nothing [Release date:: 2021-03-25]
- [x] Ep 1 - Chapter One: What the Thunder Said [Release date:: 2021-03-25]


