---
Title: The Get Down
Genre: ['Drama', 'Music']
Network: Netflix

Seasons: 2
Episodes: 11
Runtime: 62
Show_status: Ended

Status: 'Going to watch'
Rating: 
Would rewatch: 
---

## Season 2
- [ ] Ep 5 - Only from Exile Can We Come Home [Release date:: 2017-04-07]
- [ ] Ep 4 - Gamble Everything [Release date:: 2017-04-07]
- [ ] Ep 3 - One by One, Into the Dark [Release date:: 2017-04-07]
- [ ] Ep 2 - The Beat Says, This Is the Way [Release date:: 2017-04-07]
- [ ] Ep 1 - Unfold Your Own Myth [Release date:: 2017-04-07]

## Season 1
- [ ] Ep 6 - Raise Your Words, Not Your Voice [Release date:: 2016-08-12]
- [ ] Ep 5 - You Have Wings, Learn to Fly [Release date:: 2016-08-12]
- [ ] Ep 4 - Forget Safety, Be Notorious [Release date:: 2016-08-12]
- [ ] Ep 3 - Darkness Is Your Candle [Release date:: 2016-08-12]
- [ ] Ep 2 - Seek Those Who Fan Your Flames [Release date:: 2016-08-12]
- [ ] Ep 1 - Where There Is Ruin, There Is Hope for a Treasure [Release date:: 2016-08-12]


