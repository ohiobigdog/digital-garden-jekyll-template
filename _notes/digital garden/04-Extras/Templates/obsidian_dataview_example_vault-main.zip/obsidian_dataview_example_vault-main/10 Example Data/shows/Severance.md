---
Title: Severance
Genre: ['Drama', 'Science-Fiction', 'Mystery']
Network: Apple TV+

Seasons: 2
Episodes: 9
Runtime: 48
Show_status: Running

Status: 'Going to watch'
Rating: 
Would rewatch: 
---

## Season 2

## Season 1
- [ ] Ep 9 - The We We Are [Release date:: 2022-04-08]
- [ ] Ep 8 - What's for Dinner? [Release date:: 2022-04-01]
- [ ] Ep 7 - Defiant Jazz [Release date:: 2022-03-25]
- [ ] Ep 6 - Hide and Seek [Release date:: 2022-03-18]
- [ ] Ep 5 - The Grim Barbarity of Optics and Design [Release date:: 2022-03-11]
- [ ] Ep 4 - The You You Are [Release date:: 2022-03-04]
- [ ] Ep 3 - In Perpetuity [Release date:: 2022-02-25]
- [ ] Ep 2 - Half Loop [Release date:: 2022-02-18]
- [x] Ep 1 - Good News About Hell [Release date:: 2022-02-18]


