---
Title: Insatiable
Genre: ['Drama', 'Comedy']
Network: Netflix

Seasons: 2
Episodes: 22
Runtime: 46
Show_status: Ended

Status: 'Stopped watching'
Rating: 2/5
Would rewatch: 
---

## Season 2
- [ ] Ep 10 - The Most You You Can Be [Release date:: 2019-10-11]
- [ ] Ep 9 - Ladybomb [Release date:: 2019-10-11]
- [ ] Ep 8 - Pretty in Prison [Release date:: 2019-10-11]
- [ ] Ep 7 - Full Brazilian [Release date:: 2019-10-11]
- [ ] Ep 6 - Eat and Run [Release date:: 2019-10-11]
- [ ] Ep 5 - Finding Magnolia [Release date:: 2019-10-11]
- [ ] Ep 4 - Poison Patty [Release date:: 2019-10-11]
- [ ] Ep 3 - Boomerang [Release date:: 2019-10-11]
- [ ] Ep 2 - Dead Girl [Release date:: 2019-10-11]
- [ ] Ep 1 - Pig [Release date:: 2019-10-11]

## Season 1
- [x] Ep 12 - Why Bad Things Happen [Release date:: 2018-08-10]
- [x] Ep 11 - Winners Win. Period. [Release date:: 2018-08-10]
- [x] Ep 10 - Banana Heart Banana [Release date:: 2018-08-10]
- [x] Ep 9 - Bad Kitty [Release date:: 2018-08-10]
- [x] Ep 8 - Wieners and Losers [Release date:: 2018-08-10]
- [x] Ep 7 - Miss Magic Jesus [Release date:: 2018-08-10]
- [x] Ep 6 - Dunk 'N' Donut [Release date:: 2018-08-10]
- [x] Ep 5 - Bikinis and Bitches [Release date:: 2018-08-10]
- [x] Ep 4 - WMBS [Release date:: 2018-08-10]
- [x] Ep 3 - Miss Bareback Buckaroo [Release date:: 2018-08-10]
- [x] Ep 2 - Skinny Is Magic [Release date:: 2018-08-10]
- [x] Ep 1 - Pilot [Release date:: 2018-08-10]


