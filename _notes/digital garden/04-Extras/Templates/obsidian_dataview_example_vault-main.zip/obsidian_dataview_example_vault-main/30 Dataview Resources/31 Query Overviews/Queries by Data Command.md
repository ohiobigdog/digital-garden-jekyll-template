# Queries by Data Command

## SORT 
```dataview
TABLE description
FROM "20 Dataview Queries" AND #dv/sort 
```

## LIMIT 
```dataview
TABLE description
FROM "20 Dataview Queries" AND #dv/limit  
```

## FLATTEN 
```dataview
TABLE description
FROM "20 Dataview Queries" AND #dv/flatten  
```

## GROUPBY 
```dataview
TABLE description
FROM "20 Dataview Queries" AND #dv/groupby 
```
