# Queries by Type

## List
```dataview
TABLE description
FROM "20 Dataview Queries" AND #dv/list 
```

## Table
```dataview
TABLE description
FROM "20 Dataview Queries" AND #dv/table 
```

## Task
```dataview
TABLE description
FROM "20 Dataview Queries" AND #dv/task
```

## Calendar
```dataview
TABLE description
FROM "20 Dataview Queries" AND #dv/calendar  
```

## Dataviewjs
```dataview
TABLE description
FROM "20 Dataview Queries" AND #dv/dataviewjs  
```

## Inline
```dataview
TABLE description
FROM "20 Dataview Queries" AND #dv/inline  
```