# Dataview Documentation

> [!example] Find the official dataview documentation [here](https://blacksmithgu.github.io/obsidian-dataview/)

## Resources

You'll find a list of resources [in the official documentation](https://blacksmithgu.github.io/obsidian-dataview/resources-and-support/). Also, the [Obsidian Hub](https://publish.obsidian.md/hub/04+-+Guides%2C+Workflows%2C+%26+Courses/Guides/An+Introduction+to+Dataview) has a few things to offer. 